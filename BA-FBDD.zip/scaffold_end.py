

import numpy as np
import torch
import torch.nn.functional as F
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors, rdMolDescriptors
from rdkit.Chem.Scaffolds import MurckoScaffold
from collections import defaultdict


ELECTRONEGATIVITY = {
    'H': 2.20, 'C': 2.55, 'N': 3.04, 'O': 3.44, 'F': 3.98,
    'P': 2.19, 'S': 2.58, 'Cl': 3.16, 'Br': 2.96, 'I': 2.66,
    'B': 2.04, 'Si': 1.90
}


MAX_VALENCE = {
    'C': 4, 'N': 3, 'O': 2, 'S': 6, 'P': 5,
    'F': 1, 'Cl': 1, 'Br': 1, 'I': 1, 'B': 3,
    'H': 1, 'Si': 4
}


def get_murcko_scaffold_atom_indices(rdkit_mol):

    try:

        scaffold = MurckoScaffold.GetScaffoldForMol(rdkit_mol)
        if scaffold is None or scaffold.GetNumAtoms() == 0:

            return _get_ring_atoms(rdkit_mol)

        scaffold_atoms = set()
        for atom in rdkit_mol.GetAtoms():
            if atom.IsInRing():
                scaffold_atoms.add(atom.GetIdx())

        ring_info = rdkit_mol.GetRingInfo()
        ring_sets = [set(r) for r in ring_info.AtomRings()]
        for i, ri in enumerate(ring_sets):
            for j, rj in enumerate(ring_sets):
                if i >= j:
                    continue
                if ri & rj:
                    continue
                best_path = None
                for a1 in sorted(ri):
                    for a2 in sorted(rj):
                        if a1 == a2:
                            continue
                        try:
                            path = Chem.GetShortestPath(rdkit_mol, a1, a2)
                        except (RuntimeError, ValueError):
                            continue
                        if path and (best_path is None or len(path) < len(best_path)):
                            best_path = path

                if best_path:
                    scaffold_atoms.update(best_path)

        return scaffold_atoms
    except Exception:
        return _get_ring_atoms(rdkit_mol)


def _get_ring_atoms(rdkit_mol):

    ring_atoms = set()
    for atom in rdkit_mol.GetAtoms():
        if atom.IsInRing():
            ring_atoms.add(atom.GetIdx())
    return ring_atoms


def compute_scaffold_attention_scores(rdkit_mol, scaffold_atoms, embed_dim=64):

    if len(scaffold_atoms) == 0:
        return np.array([]), []

    atom_list = sorted(list(scaffold_atoms))
    n = len(atom_list)


    features = []
    for idx in atom_list:
        atom = rdkit_mol.GetAtomWithIdx(idx)
        symbol = atom.GetSymbol()

        feat = [
            atom.GetAtomicNum() / 100.0,
            atom.GetTotalValence() / 8.0,
            1.0 if atom.GetIsAromatic() else 0.0,
            atom.GetDegree() / 4.0,
            ELECTRONEGATIVITY.get(symbol, 2.5) / 4.0,
        ]
        features.append(feat)

    features = np.array(features, dtype=np.float32)  # (n, 5)


    np.random.seed(42)
    W_q = np.random.randn(features.shape[1], embed_dim).astype(np.float32) * 0.1
    W_k = np.random.randn(features.shape[1], embed_dim).astype(np.float32) * 0.1

    Q = features @ W_q  # (n, embed_dim)
    K = features @ W_k  # (n, embed_dim)


    scores = Q @ K.T  # (n, n)


    scores = scores / np.sqrt(embed_dim)


    max_scores = []
    for i in range(n):
        mask = np.ones(n, dtype=bool)
        mask[i] = False
        if n > 1:
            max_scores.append(scores[i, mask].max())
        else:
            max_scores.append(0.0)

    return np.array(max_scores), atom_list


def compute_chemical_prior_scores(rdkit_mol, scaffold_atoms):

    if len(scaffold_atoms) == 0:
        return np.array([]), []

    atom_list = sorted(list(scaffold_atoms))
    scores = []

    for idx in atom_list:
        atom = rdkit_mol.GetAtomWithIdx(idx)
        symbol = atom.GetSymbol()


        max_val = MAX_VALENCE.get(symbol, 4)
        current_val = atom.GetTotalValence()
        valence_score = max(0.0, (max_val - current_val) / max_val)


        degree = atom.GetDegree()
        steric_score = max(0.0, 1.0 - degree / max_val)


        if symbol == 'C':
            type_score = 1.0
        elif symbol == 'N':
            type_score = 0.8
        elif symbol == 'O':
            type_score = 0.4
        elif symbol == 'S':
            type_score = 0.6
        else:
            type_score = 0.3


        final_score = 0.4 * valence_score + 0.3 * steric_score + 0.3 * type_score
        scores.append(final_score)

    return np.array(scores, dtype=np.float32), atom_list


def select_growth_points(attention_scores, prior_scores, k=3,
                         alpha_att=0.5, alpha_prior=0.5):

    if len(attention_scores) == 0:
        return np.array([]), np.array([], dtype=int)


    att_min, att_max = attention_scores.min(), attention_scores.max()
    if att_max > att_min:
        att_norm = (attention_scores - att_min) / (att_max - att_min)
    else:
        att_norm = np.zeros_like(attention_scores)


    growth_scores = alpha_att * att_norm + alpha_prior * prior_scores


    k = min(k, len(growth_scores))
    top_k_indices = np.argsort(growth_scores)[-k:][::-1]

    return growth_scores, top_k_indices


def process_scaffold_end(rdkit_mol, ligand_coords, ligand_one_hot,
                         k_growth_points=3, alpha_att=0.5, alpha_prior=0.5):

    n_atoms = ligand_coords.shape[0]


    scaffold_atoms = get_murcko_scaffold_atom_indices(rdkit_mol)

    if len(scaffold_atoms) == 0:

        return {
            'scaffold_mask': np.zeros(n_atoms, dtype=bool),
            'scaffold_coords': np.zeros((0, 3), dtype=np.float32),
            'scaffold_one_hot': np.zeros((0, ligand_one_hot.shape[1]), dtype=np.float32),
            'growth_scores': np.array([], dtype=np.float32),
            'growth_points': np.array([], dtype=int),
            'scaffold_atom_indices': np.array([], dtype=int),
        }


    scaffold_mask = np.zeros(n_atoms, dtype=bool)
    scaffold_atom_list = sorted(list(scaffold_atoms))
    valid_indices = [i for i in scaffold_atom_list if i < n_atoms]
    scaffold_mask[valid_indices] = True


    scaffold_coords = ligand_coords[scaffold_mask]
    scaffold_one_hot = ligand_one_hot[scaffold_mask]


    attention_scores, _ = compute_scaffold_attention_scores(
        rdkit_mol, set(valid_indices))


    prior_scores, _ = compute_chemical_prior_scores(
        rdkit_mol, set(valid_indices))


    growth_scores, growth_points = select_growth_points(
        attention_scores, prior_scores, k=k_growth_points,
        alpha_att=alpha_att, alpha_prior=alpha_prior)


    if len(growth_points) > 0:
        scaffold_array = np.array(valid_indices)
        growth_points_global = scaffold_array[growth_points]
    else:
        growth_points_global = np.array([], dtype=int)

    return {
        'scaffold_mask': scaffold_mask,
        'scaffold_coords': scaffold_coords,
        'scaffold_one_hot': scaffold_one_hot,
        'growth_scores': growth_scores,
        'growth_points': growth_points_global,
        'scaffold_atom_indices': np.array(valid_indices, dtype=int),
    }


def build_scaffold_graph(rdkit_mol, scaffold_atoms, coords, one_hot):

    if len(scaffold_atoms) == 0:
        return (np.zeros((0, 3)), np.zeros((0, one_hot.shape[1])),
                np.zeros((2, 0), dtype=int))

    atom_list = sorted(list(scaffold_atoms))
    atom_to_idx = {a: i for i, a in enumerate(atom_list)}


    node_coords = coords[atom_list]
    node_features = one_hot[atom_list]


    edges = []
    for bond in rdkit_mol.GetBonds():
        u = bond.GetBeginAtomIdx()
        v = bond.GetEndAtomIdx()
        if u in atom_to_idx and v in atom_to_idx:
            edges.append([atom_to_idx[u], atom_to_idx[v]])
            edges.append([atom_to_idx[v], atom_to_idx[u]])  

    if len(edges) == 0:
        edge_index = np.zeros((2, 0), dtype=int)
    else:
        edge_index = np.array(edges, dtype=int).T

    return node_coords, node_features, edge_index
