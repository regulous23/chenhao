from itertools import accumulate
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset


class ProcessedLigandPocketDataset(Dataset):
    @staticmethod
    def _sections_from_sample_mask(mask, n_samples, n_items, field_name):

        if mask is None:
            if n_items == 0:

                return np.zeros(max(n_samples - 1, 0), dtype=np.int64)
            return []

        mask = np.asarray(mask, dtype=np.int64)
        counts = np.bincount(mask, minlength=n_samples)
        if counts.sum() != n_items:
            raise ValueError(
                f'{field_name}: number of items ({n_items}) does not match '
                f'sample mask counts ({counts.sum()})'
            )
        return np.cumsum(counts)[:-1]

    @staticmethod
    def _bond_pair_sections(bond_mask, n_samples, n_pairs, field_name):

        if bond_mask is None:
            return []

        bond_mask = np.asarray(bond_mask, dtype=np.int64)
        particle_counts = np.bincount(bond_mask, minlength=n_samples)
        if np.any(particle_counts % 2 != 0):
            bad = np.where(particle_counts % 2 != 0)[0][:10].tolist()
            raise ValueError(
                f'bond_mask contains an odd number of particles for samples: {bad}'
            )

        pair_counts = particle_counts // 2
        if pair_counts.sum() != n_pairs:
            raise ValueError(
                f'{field_name}: number of bond pairs ({n_pairs}) does not '
                f'match bond particles ({pair_counts.sum()})'
            )
        return np.cumsum(pair_counts)[:-1]

    @staticmethod
    def _validate_bond_arrays(data, source_name):

        bond_fields = (
            'bond_coords', 'bond_one_hot', 'bond_mask',
            'bond_atom_u', 'bond_atom_v',
        )
        present = [key for key in bond_fields if key in data]
        if not present:
            return

        missing = [key for key in bond_fields if key not in data]
        if missing:
            raise ValueError(
                f'{source_name}: incomplete bond fields; missing {missing}'
            )

        n_samples = len(data['names'])
        n_particles = len(data['bond_mask'])
        n_pairs = len(data['bond_atom_u'])

        for key in ('bond_coords', 'bond_one_hot'):
            if len(data[key]) != n_particles:
                raise ValueError(
                    f'{source_name}: {key} length ({len(data[key])}) does not '
                    f'match bond_mask length ({n_particles})'
                )
        if len(data['bond_atom_v']) != n_pairs:
            raise ValueError(
                f'{source_name}: bond_atom_u/v lengths differ '
                f'({n_pairs} vs {len(data["bond_atom_v"])})'
            )
        if n_particles != 2 * n_pairs:
            raise ValueError(
                f'{source_name}: expected two bond particles per bond, got '
                f'{n_particles} particles and {n_pairs} bonds'
            )

        bond_mask = np.asarray(data['bond_mask'], dtype=np.int64)
        if n_particles and (
                bond_mask.min() < 0 or bond_mask.max() >= n_samples):
            raise ValueError(
                f'{source_name}: bond_mask contains sample indices outside '
                f'[0, {n_samples})'
            )

        particle_counts = np.bincount(bond_mask, minlength=n_samples)
        if np.any(particle_counts % 2 != 0):
            bad = np.where(particle_counts % 2 != 0)[0][:10].tolist()
            raise ValueError(
                f'{source_name}: odd number of bond particles for samples {bad}'
            )

        pair_counts = particle_counts // 2
        lig_counts = np.bincount(
            np.asarray(data['lig_mask'], dtype=np.int64),
            minlength=n_samples,
        )
        pair_sections = np.cumsum(pair_counts)[:-1]
        u_parts = np.split(data['bond_atom_u'], pair_sections)
        v_parts = np.split(data['bond_atom_v'], pair_sections)

        for sample_idx, (u, v) in enumerate(zip(u_parts, v_parts)):
            if len(u) == 0:
                continue
            limit = lig_counts[sample_idx]
            bad_u = u[(u < 0) | (u >= limit)]
            bad_v = v[(v < 0) | (v >= limit)]
            if len(bad_u) or len(bad_v):
                name = data['names'][sample_idx]
                raise ValueError(
                    f'{source_name}: bond endpoint out of range in sample '
                    f'{sample_idx} ({name}); ligand atoms={limit}, '
                    f'bad_u={bad_u[:5].tolist()}, bad_v={bad_v[:5].tolist()}. '
                    f'Generate a bond-fix sidecar or regenerate the NPZ.'
                )

    def __init__(self, npz_path, center=True, transform=None):

        self.transform = transform
        npz_path = Path(npz_path)

        with np.load(npz_path, allow_pickle=True) as f:
            data = {key: val for key, val in f.items()}


        bond_fix_path = npz_path.with_name(f'{npz_path.stem}_bond_fix.npz')
        if bond_fix_path.exists():
            bond_fields = (
                'bond_coords', 'bond_one_hot', 'bond_mask',
                'bond_atom_u', 'bond_atom_v',
            )
            with np.load(bond_fix_path, allow_pickle=True) as f:
                missing = [key for key in bond_fields if key not in f]
                if missing:
                    raise ValueError(
                        f'{bond_fix_path}: missing bond fields {missing}'
                    )
                for key in bond_fields:
                    data[key] = f[key]
            self._validate_bond_arrays(data, str(bond_fix_path))
        else:
            self._validate_bond_arrays(data, str(npz_path))

        # split data based on mask
        self.data = {}
        for (k, v) in data.items():
            if k == 'names' or k == 'receptors':
                self.data[k] = v
                continue

            #sections = np.where(np.diff(data['lig_mask']))[0] + 1 \
            #    if 'lig' in k \
            #    else np.where(np.diff(data['pocket_mask']))[0] + 1
            axis = 0
            if 'lig' in k :
                sections = np.where(np.diff(data['lig_mask']))[0] + 1
            elif 'pocket' in k:
                sections = np.where(np.diff(data['pocket_mask']))[0] + 1
            elif 'fg_inter' in k:

                fg_inter_mask = data.get('fg_inter_mask')
                fg_inter_id = data.get('fg_inter_id')
                if fg_inter_mask is not None and fg_inter_id is not None and \
                        len(fg_inter_mask) != len(fg_inter_id):
                    raise ValueError(
                        'fg_inter_mask and fg_inter_id have different lengths; '
                        'please regenerate the preprocessed data.'
                    )
                sections = self._sections_from_sample_mask(
                    fg_inter_mask, len(data['names']), len(v), k
                )
            elif 'cross_edge' in k:

                sections = self._sections_from_sample_mask(
                    data.get('cross_edge_mask'), len(data['names']), len(v), k
                )
            elif k.startswith('internal'):

                n_items = v.shape[1] if k == 'internal_edges' else len(v)
                sections = self._sections_from_sample_mask(
                    data.get('internal_edge_mask'),
                    len(data['names']), n_items, k
                )
                axis = 1 if k == 'internal_edges' else 0
            elif k.startswith('external'):

                n_items = v.shape[1] if k == 'external_edges' else len(v)
                sections = self._sections_from_sample_mask(
                    data.get('external_edge_mask'),
                    len(data['names']), n_items, k
                )
                axis = 1 if k == 'external_edges' else 0
            elif k.startswith('final_bond') or k == 'bond_probs':

                n_items = v.shape[1] if k == 'final_bond_edges' else len(v)
                sections = self._sections_from_sample_mask(
                    data.get('final_bond_mask'),
                    len(data['names']), n_items, k
                )
                axis = 1 if k == 'final_bond_edges' else 0
            elif k in ('bond_atom_u', 'bond_atom_v'):

                sections = self._bond_pair_sections(
                    data.get('bond_mask'), len(data['names']), len(v), k
                )
            elif 'bond' in k:

                sections = self._sections_from_sample_mask(
                    data.get('bond_mask'), len(data['names']), len(v), k
                )
            elif 'fg' in k:

                sections = self._sections_from_sample_mask(
                    data.get('fg_mask'), len(data['names']), len(v), k
                )
            elif 'inter' in k:

                inter_mask = data.get('inter_mask')
                inter_id = data.get('inter_id')
                if inter_mask is not None and inter_id is not None and \
                        len(inter_mask) != len(inter_id):
                    raise ValueError(
                        'inter_mask and inter_id have different lengths. The NPZ '
                        'contains empty-interaction placeholders; regenerate it '
                        'with the updated cross_graph_modeling.py.'
                    )
                sections = self._sections_from_sample_mask(
                    inter_mask, len(data['names']), len(v), k
                )
            elif k == 'scaffold_mask':

                sections = np.where(np.diff(data['lig_mask']))[0] + 1
            elif k == 'middle_mask':

                sections = np.where(np.diff(data['lig_mask']))[0] + 1

            self.data[k] = [
                torch.from_numpy(x) for x in np.split(v, sections, axis=axis)
            ]

            # add number of nodes for convenience
            if k == 'lig_mask':
                self.data['num_lig_atoms'] = \
                    torch.tensor([len(x) for x in self.data['lig_mask']])
            elif k == 'pocket_mask':
                self.data['num_pocket_nodes'] = \
                    torch.tensor([len(x) for x in self.data['pocket_mask']])
            elif k == 'inter_mask' and 'inter_mask' in data:
                num_inter_nodes = \
                    torch.tensor([len(x)*2 for x in self.data['inter_mask']])
            elif k == 'fg_mask' and 'fg_mask' in data:
                self.data['num_fg_nodes'] = \
                    torch.tensor([len(x) for x in self.data['fg_mask']])
            elif k == 'bond_mask' and 'bond_mask' in data:
                self.data['num_bond_nodes'] = \
                    torch.tensor([len(x) for x in self.data['bond_mask']])
            elif k == 'fg_inter_mask' and 'fg_inter_mask' in data:
                num_fg_inter_nodes = \
                    torch.tensor([len(x)*2 for x in self.data['fg_inter_mask']])

        if center:
            for i in range(len(self.data['lig_coords'])):

                coords_sum = self.data['lig_coords'][i].sum(0) + \
                             self.data['pocket_coords'][i].sum(0)
                n_nodes = len(self.data['lig_coords'][i]) + \
                          len(self.data['pocket_coords'][i])


                if 'fg_coords' in self.data and i < len(self.data['fg_coords']):
                    coords_sum = coords_sum + self.data['fg_coords'][i].sum(0)
                    n_nodes = n_nodes + len(self.data['fg_coords'][i])

                if 'bond_coords' in self.data and i < len(self.data['bond_coords']):
                    coords_sum = coords_sum + self.data['bond_coords'][i].sum(0)
                    n_nodes = n_nodes + len(self.data['bond_coords'][i])

                mean = coords_sum / n_nodes
                self.data['lig_coords'][i] = self.data['lig_coords'][i] - mean
                self.data['pocket_coords'][i] = self.data['pocket_coords'][i] - mean
                if 'fg_coords' in self.data and i < len(self.data['fg_coords']):
                    self.data['fg_coords'][i] = self.data['fg_coords'][i] - mean
                if 'bond_coords' in self.data and i < len(self.data['bond_coords']):
                    self.data['bond_coords'][i] = self.data['bond_coords'][i] - mean


        if 'inter_mask' in data:
            self.data['num_pocket_nodes'] = self.data['num_pocket_nodes'] - num_inter_nodes
        if 'fg_inter_mask' in data:
            self.data['num_pocket_nodes'] = self.data['num_pocket_nodes'] - num_fg_inter_nodes

    def __len__(self):
        return len(self.data['names'])
    """
    def __getitem__(self, idx):
        data = {key: val[idx] for key, val in self.data.items()}
        if self.transform is not None:
            data = self.transform(data)
        return data
    """

    def __getitem__(self, idx):
        return {key: val[idx] for key, val in self.data.items()}

    @staticmethod
    def collate_fn(batch):
        out = {}
        for prop in batch[0].keys():

            if prop == 'names' or prop == 'receptors':
                out[prop] = [x[prop] for x in batch]
            elif prop in ('num_lig_atoms', 'num_pocket_nodes',
                          'num_virtual_atoms', 'num_fg_nodes',
                          'num_bond_nodes'):
                out[prop] = torch.tensor([x[prop] for x in batch])
            elif prop in ('scaffold_mask', 'middle_mask'):
                # Boolean masks: concatenate directly (not batch index mask)
                out[prop] = torch.cat([x[prop] for x in batch], dim=0)
            elif prop in ('internal_edges', 'external_edges',
                          'final_bond_edges'):

                offset = 0
                edge_list = []
                for x in batch:
                    e = x[prop].long()
                    if e.numel() > 0:
                        e = e + offset
                    edge_list.append(e)
                    offset += int(x['num_lig_atoms'])
                out[prop] = torch.cat(edge_list, dim=1)
            elif 'mask' in prop:
                # Batch index masks: offset by batch index
                # make sure indices in batch start at zero (needed for
                # torch_scatter)
                out[prop] = torch.cat([i * torch.ones(len(x[prop]))
                                       for i, x in enumerate(batch)], dim=0)
            else:
                out[prop] = torch.cat([x[prop] for x in batch], dim=0)

        return out
