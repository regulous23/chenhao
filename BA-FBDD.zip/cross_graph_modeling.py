
import oddt
import numpy as np
from oddt.interactions import close_contacts
from tqdm import tqdm
import argparse
from pathlib import Path
from collections import namedtuple


FG_TYPES = [
    'hydroxyl',        # 0:  羟基 -OH
    'carbonyl',        # 1:  羰基 C=O（醛/酮）
    'carboxylic_acid', # 2:  羧酸 -COOH
    'ester',           # 3:  酯 -COOR
    'amide',           # 4:  酰胺 -CONH-
    'amine',           # 5:  胺 -NH2, -NHR, -NR2
    'nitro',           # 6:  硝基 -NO2
    'nitrile',         # 7:  腈 -C≡N
    'aromatic_ring',   # 8:  芳香环（作为官能团的一部分）
    'halogen',         # 9:  卤素 -F, -Cl, -Br, -I
    'sulfonyl',        # 10: 磺酰/砜 -SO2-
    'thiol',           # 11: 硫醇/硫醚 -SH, -SR
    'phosphate',       # 12: 磷酸/磷酯 -PO4
    'alkene',          # 13: 烯烃 C=C
    'alkyne',          # 14: 炔烃 C≡C
    'ether',           # 15: 醚 C-O-C
    'other',           # 16: 其他/未分类
]
N_FG_TYPES = len(FG_TYPES)


BOND_TYPES = ['SINGLE', 'DOUBLE', 'TRIPLE', 'AROMATIC', 'OTHER']
N_BOND_TYPES = len(BOND_TYPES)


LIG_ATOMICNUM_TO_TYPE_IDX = {
    6: 0,    # C
    7: 1,    # N
    8: 2,    # O
    16: 3,   # S
    5: 4,    # B
    35: 5,   # Br
    17: 6,   # Cl
    15: 7,   # P
    53: 8,   # I
    9: 9,    # F
}


def build_ligand_one_hot_from_oddt(ligand, n_atom_types=10):
    """根据ODDT原子序数构建配体one-hot，未知原子按碳处理。"""
    one_hot = np.zeros((len(ligand.atoms), n_atom_types), dtype=np.float32)
    for i, atom in enumerate(ligand.atoms):
        type_idx = LIG_ATOMICNUM_TO_TYPE_IDX.get(int(atom.atomicnum), 0)
        if type_idx < n_atom_types:
            one_hot[i, type_idx] = 1.0
    return one_hot


RDKIT_BOND_TYPE_MAP = {
    1: 0,   # SINGLE
    2: 1,   # DOUBLE
    3: 2,   # TRIPLE
    12: 3,  # AROMATIC (RDKit内部值为12)
}


CUSTOM_FG_PATTERNS = {
    'hydroxyl':        '[OX2H]',
    'carbonyl':        '[#6][CX3](=O)[#6]',  # 酮/醛的羰基
    'carboxylic_acid': '[CX3](=O)[OX2H1]',
    'ester':           '[#6][CX3](=O)[OX2][#6]',
    'amide':           '[NX3][CX3](=[OX1])[#6]',
    'amine':           '[NX3;H2,H1;!$(NC=O)]',
    'nitro':           '[$([NX3](=O)=O),$([NX3+](=O)[O-])]',
    'nitrile':         '[CX1]#[NX1]',
    'halogen':         '[F,Cl,Br,I]',
    'sulfonyl':        '[$([#16X4](=[OX1])(=[OX1])),$([#16X4+]([OX1-])(=[OX1]))]',
    'thiol':           '[SX2H]',
    'phosphate':       '[PX4](=O)([OX2])',  # 简化磷酸模式
    'alkene':          'C=C',
    'alkyne':          'C#C',
    'ether':           '[OD2]([#6])[#6]',  # 非酯/非环醚
}

def build_oddt_rdkit_atom_mapping(oddt_mol, rdkit_mol, tol=1e-3):
    oddt_coords = np.array([atom.coords for atom in oddt_mol.atoms])
    
    conf = rdkit_mol.GetConformer()
    rdkit_coords = np.array([
        conf.GetAtomPosition(i) for i in range(rdkit_mol.GetNumAtoms())
    ])
    
    mapping = {}
    used_rdkit = set()
    
    for oi, oc in enumerate(oddt_coords):
        dists = np.linalg.norm(rdkit_coords - oc, axis=1)
        # 排除已匹配的RDKit原子
        for ri in np.argsort(dists):
            if ri in used_rdkit:
                continue
            if dists[ri] < tol:
                mapping[oi] = ri
                used_rdkit.add(ri)
                break
    
    return mapping


def classify_functional_group(pseudo_smiles, atom_symbols):
    ps = pseudo_smiles.lower()
    syms = set(s.upper() for s in atom_symbols)
    

    if ('c(=o)o' in ps or '[car](=o)[oar]' in ps or 'c(=o)[oh]' in ps):
        if 'N' not in syms:
            return FG_TYPES.index('carboxylic_acid')
    

    if ('c(=o)o' in ps or '[car](=o)[oar]' in ps or 'coor' in ps):
        if 'N' not in syms:
            return FG_TYPES.index('ester')
    

    if ('c(=o)n' in ps or '[car](=o)[nar]' in ps or 'c(=o)[n]' in ps):
        return FG_TYPES.index('amide')
    

    if ('[oh]' in ps or 'oh' in ps) and '=o' not in ps:
        return FG_TYPES.index('hydroxyl')
    

    if '=o' in ps or '[car]=[oar]' in ps:
        return FG_TYPES.index('carbonyl')
    

    if ('[n+](=o)[o-]' in ps or 'no2' in ps or 'nitro' in ps):
        return FG_TYPES.index('nitro')
    

    if 'c#n' in ps or '[car]#[n]' in ps:
        return FG_TYPES.index('nitrile')
    

    if 'N' in syms:
        n_count = sum(1 for s in atom_symbols if s.upper() == 'N')
        o_count = sum(1 for s in atom_symbols if s.upper() == 'O')
        if n_count >= 1 and o_count == 0:
            return FG_TYPES.index('amine')
    

    if 'S' in syms:
        s_count = sum(1 for s in atom_symbols if s.upper() == 'S')
        o_count = sum(1 for s in atom_symbols if s.upper() == 'O')
        if s_count >= 1 and o_count >= 2:
            return FG_TYPES.index('sulfonyl')
    

    if 'S' in syms:
        return FG_TYPES.index('thiol')
    

    if 'P' in syms:
        return FG_TYPES.index('phosphate')
    

    if any(h in syms for h in ['F', 'CL', 'BR', 'I']):
        return FG_TYPES.index('halogen')
    

    c_count = sum(1 for s in atom_symbols if s.upper() == 'C')
    if c_count >= 3 and all(s in ['C', 'H'] for s in syms):

        if ps.count('car') >= 2:
            return FG_TYPES.index('aromatic_ring')
    

    if 'c=c' in ps or '[car]=[car]' in ps:
        return FG_TYPES.index('alkene')
    

    if 'c#c' in ps or '#c' in ps:
        return FG_TYPES.index('alkyne')
    

    if 'O' in syms and 'N' not in syms and '=O' not in ps:
        o_count = sum(1 for s in atom_symbols if s.upper() == 'O')
        if o_count == 1:
            return FG_TYPES.index('ether')
    

    return FG_TYPES.index('other')


def rdkit_bond_type_to_index(bond):

    from rdkit import Chem
    bond_type = bond.GetBondType()
    type_val = int(bond_type)
    
    # RDKit AROMATIC的枚举值为12
    if bond_type == Chem.BondType.AROMATIC or type_val == 12:
        return 3  # AROMATIC
    
    return RDKIT_BOND_TYPE_MAP.get(type_val, 4)  # 默认OTHER


def detect_functional_groups(rdkit_mol):

    fg_list = []
    

    try:

        mol_work = Chem.RemoveHs(rdkit_mol) if rdkit_mol.GetNumAtoms() > 0 else rdkit_mol
        

        import importlib
        efgs_module = importlib.import_module('rdkit.Contrib.efgs.efgs')
        get_dec_fgs = efgs_module.get_dec_fgs
        
        img_text, fgs, psmis, fg_mols = get_dec_fgs(mol_work, verbose=False)
        
        for i, (atom_set, psmi) in enumerate(zip(fgs, psmis)):

            valid_indices = set()
            atom_symbols = []
            for idx in atom_set:
                if idx < rdkit_mol.GetNumAtoms():
                    valid_indices.add(idx)
                    atom_symbols.append(rdkit_mol.GetAtomWithIdx(idx).GetSymbol())
            
            if len(valid_indices) == 0:
                continue
            
            fg_type_idx = classify_functional_group(psmi, atom_symbols)
            
            fg_list.append({
                'atom_indices': valid_indices,
                'fg_type': fg_type_idx,
                'pseudo_smiles': psmi,
            })
        
        if len(fg_list) > 0:
            return fg_list
    except Exception as e:
        pass  
    

    try:
        import importlib
        ifg_module = importlib.import_module('rdkit.Contrib.IFG.ifg')
        identify_functional_groups = ifg_module.identify_functional_groups
        
        ifgs = identify_functional_groups(rdkit_mol)
        
        for ifg in ifgs:
            atom_ids = set(ifg.atomIds)
            atom_symbols = [rdkit_mol.GetAtomWithIdx(i).GetSymbol() for i in atom_ids]
            fg_type_idx = classify_functional_group(ifg.type, atom_symbols)
            
            fg_list.append({
                'atom_indices': atom_ids,
                'fg_type': fg_type_idx,
                'pseudo_smiles': ifg.type,
            })
        
        if len(fg_list) > 0:
            return fg_list
    except Exception as e:
        pass
    

    try:
        from rdkit import Chem
        
        matched_atoms = set()  
        
        for fg_name, smarts in CUSTOM_FG_PATTERNS.items():
            patt = Chem.MolFromSmarts(smarts)
            if patt is None:
                continue
            
            matches = rdkit_mol.GetSubstructMatches(patt)
            for match in matches:
                match_set = set(match)

                if len(match_set & matched_atoms) <= len(match_set) * 0.5:
                    fg_type_idx = FG_TYPES.index(fg_name) if fg_name in FG_TYPES else FG_TYPES.index('other')
                    fg_list.append({
                        'atom_indices': match_set,
                        'fg_type': fg_type_idx,
                        'pseudo_smiles': smarts,
                    })
                    matched_atoms.update(match_set)
        
        if len(fg_list) > 0:
            return fg_list
    except Exception as e:
        pass
    

    for i, atom in enumerate(rdkit_mol.GetAtoms()):
        if atom.GetAtomicNum() != 1:  
            sym = atom.GetSymbol()

            if sym in ['F', 'Cl', 'Br', 'I']:
                fg_type = FG_TYPES.index('halogen')
            elif sym == 'O':
                fg_type = FG_TYPES.index('hydroxyl')
            elif sym == 'N':
                fg_type = FG_TYPES.index('amine')
            elif sym == 'S':
                fg_type = FG_TYPES.index('thiol')
            elif sym == 'P':
                fg_type = FG_TYPES.index('phosphate')
            else:
                fg_type = FG_TYPES.index('other')
            
            fg_list.append({
                'atom_indices': {i},
                'fg_type': fg_type,
                'pseudo_smiles': sym,
            })
    
    return fg_list


def build_functional_group_graph(rdkit_mol, fg_list, oddt_to_rdkit_mapping=None):

    if len(fg_list) == 0:
        return np.zeros((0, 3)), np.zeros((0, N_FG_TYPES)), []
    
    conf = rdkit_mol.GetConformer()
    fg_coords_list = []
    fg_one_hot_list = []
    fg_rdkit_atom_map = []
    
    for fg in fg_list:
        atom_indices = list(fg['atom_indices'])
        

        coords = np.array([
            list(conf.GetAtomPosition(idx)) for idx in atom_indices
            if idx < rdkit_mol.GetNumAtoms()
        ])
        
        if len(coords) == 0:
            continue
        
        center = coords.mean(axis=0)
        fg_coords_list.append(center)
        

        oh = np.zeros(N_FG_TYPES)
        oh[fg['fg_type']] = 1.0
        fg_one_hot_list.append(oh)
        
        fg_rdkit_atom_map.append(atom_indices)
    
    fg_coords = np.array(fg_coords_list) if fg_coords_list else np.zeros((0, 3))
    fg_one_hot = np.array(fg_one_hot_list) if fg_one_hot_list else np.zeros((0, N_FG_TYPES))
    
    return fg_coords, fg_one_hot, fg_rdkit_atom_map


def build_cross_edges(n_atoms, fg_rdkit_atom_map, rdkit_to_oddt_mapping=None):

    atom_indices = []
    fg_indices = []
    
    for fg_idx, atom_map in enumerate(fg_rdkit_atom_map):
        for rdkit_atom_idx in atom_map:

            if rdkit_to_oddt_mapping:
                if rdkit_atom_idx not in rdkit_to_oddt_mapping:
                    continue
                atom_idx = rdkit_to_oddt_mapping[rdkit_atom_idx]
            else:
                atom_idx = rdkit_atom_idx
            if atom_idx < n_atoms:
                atom_indices.append(atom_idx)
                fg_indices.append(fg_idx)
    
    if len(atom_indices) == 0:
        return np.array([], dtype=int), np.array([], dtype=int)
    
    return np.array(atom_indices, dtype=int), np.array(fg_indices, dtype=int)


def build_bond_particles(rdkit_mol, rdkit_to_oddt_mapping=None):

    conf = rdkit_mol.GetConformer()

    bond_coords_list = []
    bond_one_hot_list = []
    bond_u_list = []
    bond_v_list = []

    for bond in rdkit_mol.GetBonds():
        u = bond.GetBeginAtomIdx()
        v = bond.GetEndAtomIdx()

        if rdkit_to_oddt_mapping:
            if u not in rdkit_to_oddt_mapping or v not in rdkit_to_oddt_mapping:
                continue
            u_oddt = rdkit_to_oddt_mapping[u]
            v_oddt = rdkit_to_oddt_mapping[v]
        else:
            u_oddt = u
            v_oddt = v

        # 获取坐标
        pos_u = np.array(list(conf.GetAtomPosition(u)))
        pos_v = np.array(list(conf.GetAtomPosition(v)))

        xe_u_bias = (2.0 * pos_u + pos_v) / 3.0
        xe_v_bias = (pos_u + 2.0 * pos_v) / 3.0

        bond_coords_list.extend([xe_u_bias, xe_v_bias])

        bt_idx = rdkit_bond_type_to_index(bond)
        oh = np.zeros(N_BOND_TYPES)
        oh[bt_idx] = 1.0
        bond_one_hot_list.extend([oh, oh]) 

        bond_u_list.append(u_oddt)
        bond_v_list.append(v_oddt)

    if len(bond_coords_list) == 0:
        return (np.zeros((0, 3)), np.zeros((0, N_BOND_TYPES)),
                np.array([], dtype=int), np.array([], dtype=int))

    return (np.array(bond_coords_list), np.array(bond_one_hot_list),
            np.array(bond_u_list, dtype=int), np.array(bond_v_list, dtype=int))


def all_contacts_create(protein, ligand, cutoff=4.5):

    po_coords_list = []
    po_ids_list = []
    for atom in protein.atoms:
        try:
            if atom.atomicnum == 1:
                continue 
        except AttributeError:
            pass  
        
        coords = atom.coords
        if coords is None or len(coords) != 3:
            continue
        po_coords_list.append(np.array(coords, dtype=float))
        po_ids_list.append(atom.idx0 if hasattr(atom, 'idx0') else atom.idx)
    
    li_coords_list = []
    li_ids_list = []
    for atom in ligand.atoms:
        try:
            if atom.atomicnum == 1:
                continue
        except AttributeError:
            pass
        
        coords = atom.coords
        if coords is None or len(coords) != 3:
            continue
        li_coords_list.append(np.array(coords, dtype=float))
        li_ids_list.append(atom.idx0 if hasattr(atom, 'idx0') else atom.idx)
    
    po_coords = np.array(po_coords_list) if po_coords_list else np.zeros((0, 3))
    li_coords = np.array(li_coords_list) if li_coords_list else np.zeros((0, 3))
    
    if len(po_coords) == 0 or len(li_coords) == 0:
        return [[]], np.array([]).reshape(0, 3), np.identity(2)[[0, 1] * 0].reshape(0, 2)
    
    int_id = []
    coords_po_bias = []
    coords_li_bias = []
    
    for li_idx in range(len(li_coords)):
        for po_idx in range(len(po_coords)):
            dist = np.linalg.norm(li_coords[li_idx] - po_coords[po_idx])
            if dist < cutoff:
                int_id.append([li_ids_list[li_idx], 0, po_ids_list[po_idx], 0])

                coords_po_bias.append((2 * po_coords[po_idx] + li_coords[li_idx]) / 3)

                coords_li_bias.append((po_coords[po_idx] + 2 * li_coords[li_idx]) / 3)
    
    if len(int_id) == 0:
        return [[]], np.array([]).reshape(0, 3), np.identity(2)[[0, 1] * 0].reshape(0, 2)
    

    inter_coords = []
    [inter_coords.append(item) for pair in zip(coords_po_bias, coords_li_bias) for item in pair]
    inter_coords = np.array(inter_coords)
    
    n_pairs = len(coords_po_bias)
    po_li_id = np.array([0, 1] * n_pairs)
    inter_one_hot = np.identity(2)[po_li_id]
    
    return int_id, inter_coords, inter_one_hot


def fg_protein_interactions_create(protein, ligand, fg_coords, fg_rdkit_atom_map,
                                     oddt_to_rdkit_mapping, cutoff=4.5):

    if len(fg_coords) == 0 or len(fg_rdkit_atom_map) == 0:
        return [[]], np.array([]).reshape(0, 3), np.identity(2)[[0, 1] * 0].reshape(0, 2), np.array([], dtype=int)
    

    rdkit_to_oddt = {v: k for k, v in oddt_to_rdkit_mapping.items()} if oddt_to_rdkit_mapping else {}
    

    protein_atoms_list = []
    for atom in protein.atoms:
        try:
            if atom.atomicnum == 1:
                continue
        except AttributeError:
            pass
        protein_atoms_list.append(atom)
    
    ligand_atoms_list = []
    for atom in ligand.atoms:
        try:
            if atom.atomicnum == 1:
                continue
        except AttributeError:
            pass
        ligand_atoms_list.append(atom)
    
    po_coords_all = np.array([a.coords for a in protein_atoms_list]) if protein_atoms_list else np.zeros((0, 3))
    li_coords_all = np.array([a.coords for a in ligand_atoms_list]) if ligand_atoms_list else np.zeros((0, 3))
    
    if len(po_coords_all) == 0 or len(li_coords_all) == 0:
        return [[]], np.array([]).reshape(0, 3), np.identity(2)[[0, 1] * 0].reshape(0, 2), np.array([], dtype=int)
    

    close_pairs = []
    for li_idx in range(len(li_coords_all)):
        for po_idx in range(len(po_coords_all)):
            dist = np.linalg.norm(li_coords_all[li_idx] - po_coords_all[po_idx])
            if dist < cutoff:
                close_pairs.append((li_idx, po_idx))
    

    fg_po_pairs = []  
    
    for li_idx, po_idx in close_pairs:
        li_atom = ligand_atoms_list[li_idx]
        po_atom = protein_atoms_list[po_idx]
        li_id = li_atom.idx0 if hasattr(li_atom, 'idx0') else li_atom.idx
        po_id = po_atom.idx0 if hasattr(po_atom, 'idx0') else po_atom.idx
        li_coords = li_atom.coords
        po_coords = po_atom.coords
        

        rdkit_idx = oddt_to_rdkit_mapping.get(li_id, None) if oddt_to_rdkit_mapping else li_id
        
        if rdkit_idx is None:
            continue
        

        for fg_idx, atom_map in enumerate(fg_rdkit_atom_map):
            if rdkit_idx in atom_map:
                fg_po_pairs.append((fg_idx, po_id, po_coords, fg_coords[fg_idx]))
    
    if len(fg_po_pairs) == 0:
        return [[]], np.array([]).reshape(0, 3), np.identity(2)[[0, 1] * 0].reshape(0, 2), np.array([], dtype=int)
    

    seen = set()
    unique_pairs = []
    for fg_idx, po_id, po_coords, fg_coord in fg_po_pairs:
        key = (fg_idx, po_id)
        if key not in seen:
            seen.add(key)
            unique_pairs.append((fg_idx, po_id, po_coords, fg_coord))
    

    fg_inter_id = []
    fg_inter_coords_list = []
    fg_inter_fg_idx_list = []
    
    for fg_idx, po_id, po_coords, fg_coord in unique_pairs:
        po_coords_arr = np.array(po_coords, dtype=float)
        fg_coord_arr = np.array(fg_coord, dtype=float)

        p1 = (2.0 / 3.0) * po_coords_arr + (1.0 / 3.0) * fg_coord_arr

        p2 = (1.0 / 3.0) * po_coords_arr + (2.0 / 3.0) * fg_coord_arr
        
        fg_inter_coords_list.extend([p1, p2])
        fg_inter_id.append([fg_idx, 0, po_id, 0])
        fg_inter_fg_idx_list.append(fg_idx)
    
    fg_inter_coords = np.array(fg_inter_coords_list)
    n_pairs = len(unique_pairs)
    po_fg_id = np.array([0, 1] * n_pairs)  
    fg_inter_one_hot = np.identity(2)[po_fg_id]
    
    return fg_inter_id, fg_inter_coords, fg_inter_one_hot, np.array(fg_inter_fg_idx_list, dtype=int)


def process_single_complex(protein, ligand, rdkit_mol, one_hot_len,
                           ligand_one_hot=None):

    oddt_to_rdkit = build_oddt_rdkit_atom_mapping(ligand, rdkit_mol)
    rdkit_to_oddt = {v: k for k, v in oddt_to_rdkit.items()}
    
    n_lig_atoms = len(ligand.atoms)
    if ligand_one_hot is None or len(ligand_one_hot) != n_lig_atoms:
        ligand_one_hot = build_ligand_one_hot_from_oddt(ligand)
    else:
        ligand_one_hot = np.asarray(ligand_one_hot, dtype=np.float32)
    

    int_id, inter_coords, inter_one_hot = all_contacts_create(protein, ligand)
    has_inter = len(int_id[0]) > 0
    

    fg_list = detect_functional_groups(rdkit_mol)
    fg_coords, fg_one_hot, fg_rdkit_atom_map = build_functional_group_graph(
        rdkit_mol, fg_list, oddt_to_rdkit
    )
    n_fgs = len(fg_coords)
    has_fgs = n_fgs > 0
    

    cross_atom_idx, cross_fg_idx = build_cross_edges(
        n_lig_atoms, fg_rdkit_atom_map, rdkit_to_oddt
    )
    has_cross = len(cross_atom_idx) > 0
    

    bond_coords, bond_one_hot, bond_atom_u, bond_atom_v = build_bond_particles(
        rdkit_mol, rdkit_to_oddt
    )
    n_bonds = len(bond_coords)
    has_bonds = n_bonds > 0

    fg_inter_id, fg_inter_coords, fg_inter_one_hot, fg_inter_fg_idx = \
        fg_protein_interactions_create(
            protein, ligand, fg_coords, fg_rdkit_atom_map, oddt_to_rdkit
        )
    has_fg_inter = len(fg_inter_id[0]) > 0 if len(fg_inter_id) > 0 else False

    NEW_ONE_HOT_DIM = one_hot_len + 2 + 2 
    

    po_one_expanded = np.zeros((one_hot_len + 2 + 2,))
    
    inter_one_expanded = np.zeros((NEW_ONE_HOT_DIM,))
    if has_inter and len(inter_one_hot) > 0:
        inter_one_expanded_local = np.zeros((len(inter_one_hot), NEW_ONE_HOT_DIM))
        inter_one_expanded_local[:, one_hot_len:one_hot_len+2] = inter_one_hot
        inter_one_hot = inter_one_expanded_local
    

    fg_inter_one_expanded = np.zeros((NEW_ONE_HOT_DIM,))
    if has_fg_inter and len(fg_inter_one_hot) > 0:
        fg_inter_one_expanded_local = np.zeros((len(fg_inter_one_hot), NEW_ONE_HOT_DIM))
        fg_inter_one_expanded_local[:, one_hot_len+2:one_hot_len+4] = fg_inter_one_hot
        fg_inter_one_hot = fg_inter_one_expanded_local
    

    scaffold_result = None
    if rdkit_mol is not None and rdkit_mol.GetNumConformers() > 0:
        try:
            from scaffold_end import process_scaffold_end
            lig_coords_all = np.array([atom.coords for atom in ligand.atoms])
            lig_one_hot_all = ligand_one_hot
            scaffold_result = process_scaffold_end(
                rdkit_mol, lig_coords_all, lig_one_hot_all,
                k_growth_points=3, alpha_att=0.5, alpha_prior=0.5)
        except Exception:
            pass

    middle_result = None
    if scaffold_result is not None:
        try:
            from middle_segment import process_middle_segment
            middle_result = process_middle_segment(
                lig_coords_all, lig_one_hot_all,
                scaffold_result['scaffold_mask'],
                protein_inter_mask=None,
                build_bond_filter=True, beta=0.8, gamma=0.3, tau=0.3)
        except Exception:
            pass

    result = {
        'int_id': int_id if has_inter else [[]],
        'inter_coords': inter_coords if has_inter else np.array([]).reshape(0, 3),
        'inter_one_hot': inter_one_hot if has_inter else np.array([]).reshape(0, NEW_ONE_HOT_DIM),
        'has_inter': has_inter,
        
        'fg_coords': fg_coords,
        'fg_one_hot': fg_one_hot,
        'has_fgs': has_fgs,
        
        'cross_atom_idx': cross_atom_idx if has_cross else np.array([], dtype=int),
        'cross_fg_idx': cross_fg_idx if has_cross else np.array([], dtype=int),
        'has_cross': has_cross,
        
        'bond_coords': bond_coords,
        'bond_one_hot': bond_one_hot,
        'bond_atom_u': bond_atom_u,
        'bond_atom_v': bond_atom_v,
        'has_bonds': has_bonds,
        
        'fg_inter_id': fg_inter_id if has_fg_inter else [[]],
        'fg_inter_coords': fg_inter_coords if has_fg_inter else np.array([]).reshape(0, 3),
        'fg_inter_one_hot': fg_inter_one_hot if has_fg_inter else np.array([]).reshape(0, NEW_ONE_HOT_DIM),
        'fg_inter_fg_idx': fg_inter_fg_idx if has_fg_inter else np.array([], dtype=int),
        'has_fg_inter': has_fg_inter,
        
        'new_one_hot_dim': NEW_ONE_HOT_DIM,
        'po_one_expanded_shape': (NEW_ONE_HOT_DIM,),
    }

    # Add scaffold-end fields if precomputed
    if scaffold_result is not None:
        result['scaffold_mask'] = scaffold_result['scaffold_mask']
        result['scaffold_coords'] = scaffold_result['scaffold_coords']
        result['scaffold_one_hot'] = scaffold_result['scaffold_one_hot']
        result['growth_scores'] = scaffold_result['growth_scores']
        result['growth_points'] = scaffold_result['growth_points']
        result['scaffold_atom_indices'] = scaffold_result['scaffold_atom_indices']

    # Add middle-segment fields if precomputed
    if middle_result is not None:
        result['middle_mask'] = middle_result['middle_mask']
        result['middle_coords'] = middle_result['middle_coords']
        result['middle_one_hot'] = middle_result['middle_one_hot']
        result['internal_edges'] = middle_result['internal_edges']
        result['internal_edge_dist'] = middle_result['internal_edge_dist']
        result['external_edges'] = middle_result['external_edges']
        result['external_edge_dist'] = middle_result['external_edge_dist']
        result['final_bond_edges'] = middle_result['final_bond_edges']
        result['bond_probs'] = middle_result['bond_probs']
        result['final_bond_probs'] = middle_result['final_bond_probs']
        result['middle_indices'] = middle_result['middle_indices']

    return result


def data_create(file, base_path):


    inter_id = []
    inter_mask = []
    pocket_coords = []
    pocket_one_hot = []
    

    all_fg_coords = []
    all_fg_one_hot = []
    all_fg_mask = []
    
    all_cross_atom_idx = []
    all_cross_fg_idx = []
    all_cross_mask = []
    
    all_bond_coords = []
    all_bond_one_hot = []
    all_bond_mask = []
    all_bond_atom_u = []
    all_bond_atom_v = []
    
    all_fg_inter_id = []
    all_fg_inter_mask = []
    

    all_scaffold_masks = []
    all_growth_points_list = []
    

    all_middle_masks = []
    all_internal_edges = []
    all_internal_edge_dist = []
    all_internal_edge_mask = []
    all_external_edges = []
    all_external_edge_dist = []
    all_external_edge_mask = []
    all_final_bond_edges = []
    all_final_bond_probs = []
    all_final_bond_mask = []
    
    pdb_name = [Path(x.split('.pdb_')[0]+'.pdb').name for x in file['names']]
    lig_name = [Path(x.split('.pdb_')[1]).name for x in file['names']]
    one_hot_len = len(file['pocket_one_hot'][0])

    sec_lig = np.where(np.diff(file['lig_mask']))[0] + 1
    lig_coords_per_sample = np.split(file['lig_coords'], sec_lig)
    lig_one_hot_per_sample = np.split(file['lig_one_hot'], sec_lig)
    lig_counts_per_sample = [len(chunk) for chunk in lig_coords_per_sample]
    while len(lig_counts_per_sample) < len(file['names']):
        lig_counts_per_sample.append(
            len(file['lig_coords']) - sum(lig_counts_per_sample)
        )

    from rdkit import Chem
    
    def find_file(base, name):
        basename = Path(name).name  # filename only
        subdir = str(Path(name).parent) if '/' in name or '\\' in name else None
        # Also try basename with underscores replaced by dashes
        basename_dash = basename.replace('_', '-')

        candidates = [basename]
        if basename_dash != basename:
            candidates.append(basename_dash)

        # 1. Try direct path (name may already include subdirs)
        direct = Path(base, name)
        if direct.exists():
            return direct
        for c in candidates:
            if subdir and subdir not in ('.', ''):
                p = Path(base, subdir, c)
                if p.exists():
                    return p

        # 2. Try common subdirectories
        subdirs_to_try = ['', 'pdb', 'sdf', 'test_pdb_10', 'test_sdf',
                          'val_pdb', 'val_sdf', 'train_pdb', 'train_sdf']
        if subdir and subdir not in ('.', ''):
            subdirs_to_try.insert(0, subdir)
        for sub in subdirs_to_try:
            for c in candidates:
                p = Path(base, sub, c) if sub else Path(base, c)
                if p.exists():
                    return p

        # 3. Full recursive search for basename variants
        for c in candidates:
            matches = list(Path(base).rglob(c))
            if matches:
                return matches[0]

        # 4. Full recursive search for just the stem (without extension)
        for c in candidates:
            stem = Path(c).stem
            matches = list(Path(base).rglob(stem + '.*'))
            if matches:
                return matches[0]

        # 5. Return original path for a clean error message
        return direct

    first_pdb_path = find_file(base_path, pdb_name[0])
    first_sdf_path = find_file(base_path, lig_name[0])
    first_protein = next(oddt.toolkit.readfile('pdb', str(first_pdb_path)))
    first_ligand = next(oddt.toolkit.readfile('sdf', str(first_sdf_path)))
    first_protein.protein = True
    first_ligand.removeh()
    
    first_rdkit = Chem.MolFromMolFile(str(first_sdf_path), removeHs=False)
    if first_rdkit is None:
        first_rdkit = Chem.MolFromMolBlock(first_ligand.write('sdf'), removeHs=False)
    
    if first_rdkit and first_rdkit.GetNumConformers() > 0:
        tmp_result = process_single_complex(
            first_protein, first_ligand, first_rdkit, one_hot_len,
            ligand_one_hot=lig_one_hot_per_sample[0]
        )
        NEW_DIM = tmp_result['new_one_hot_dim']
    else:
        NEW_DIM = one_hot_len + 4
    
    po_one_tmp1 = np.append(file['pocket_one_hot'], np.zeros((len(file['pocket_one_hot']), 4)), axis=1)
    
    sec_poc = np.where(np.diff(file['pocket_mask']))[0] + 1
    po_cor_tmp2 = np.split(file['pocket_coords'], sec_poc)
    po_one_tmp2 = np.split(po_one_tmp1, sec_poc)
    
    fg_idx_offset = 0  
    
    for i in tqdm(range(len(file['names']))):
        pdb_path = find_file(base_path, pdb_name[i])
        sdf_path = find_file(base_path, lig_name[i])
        protein = next(oddt.toolkit.readfile('pdb', str(pdb_path)))
        ligand = next(oddt.toolkit.readfile('sdf', str(sdf_path)))
        protein.protein = True
        ligand.removeh()
        

        rdkit_mol = Chem.MolFromMolFile(str(sdf_path), removeHs=False)
        if rdkit_mol is None:

            try:
                sdf_block = ligand.write('sdf')
                rdkit_mol = Chem.MolFromMolBlock(sdf_block, removeHs=False)
            except:
                rdkit_mol = None
        
        if rdkit_mol is None or rdkit_mol.GetNumConformers() == 0:

            int_id_i, inter_coords_i, inter_one_hot_i = all_contacts_create(protein, ligand)
            
            if len(int_id_i[0]) > 0:
                [inter_id.append(x) for x in int_id_i]

                [inter_mask.append(x) for x in np.full(len(int_id_i), i)]
            
            if len(inter_one_hot_i) > 0:
                inter_one_expanded = np.zeros((len(inter_one_hot_i), NEW_DIM))
                inter_one_expanded[:, one_hot_len:one_hot_len+2] = inter_one_hot_i
                po_int_cor_tmp3 = np.append(po_cor_tmp2[i], inter_coords_i, axis=0)
                po_int_one_tmp3 = np.append(po_one_tmp2[i], inter_one_expanded, axis=0)
            else:
                po_int_cor_tmp3 = po_cor_tmp2[i]
                po_int_one_tmp3 = po_one_tmp2[i]
            
            pocket_coords.append(po_int_cor_tmp3)
            pocket_one_hot.append(po_int_one_tmp3)
            

            all_fg_coords.append(np.zeros((0, 3)))
            all_fg_one_hot.append(np.zeros((0, N_FG_TYPES)))
            all_cross_atom_idx.append(np.array([], dtype=int))
            all_cross_fg_idx.append(np.array([], dtype=int))
            all_bond_coords.append(np.zeros((0, 3)))
            all_bond_one_hot.append(np.zeros((0, N_BOND_TYPES)))
            all_bond_atom_u.append(np.array([], dtype=int))
            all_bond_atom_v.append(np.array([], dtype=int))


            n_lig_atoms_i = lig_counts_per_sample[i]
            all_scaffold_masks.append(np.zeros(n_lig_atoms_i, dtype=bool))
            all_growth_points_list.append(np.array([], dtype=int))
            all_middle_masks.append(np.zeros(n_lig_atoms_i, dtype=bool))
            all_internal_edges.append(np.zeros((2, 0), dtype=int))
            all_internal_edge_dist.append(np.array([], dtype=np.float32))
            all_external_edges.append(np.zeros((2, 0), dtype=int))
            all_external_edge_dist.append(np.array([], dtype=np.float32))
            all_final_bond_edges.append(np.zeros((2, 0), dtype=int))
            all_final_bond_probs.append(np.array([], dtype=np.float32))
            continue
        

        result = process_single_complex(
            protein, ligand, rdkit_mol, one_hot_len,
            ligand_one_hot=lig_one_hot_per_sample[i]
        )
        

        if result['has_inter']:
            [inter_id.append(x) for x in result['int_id']]

            [inter_mask.append(x) for x in np.full(len(result['int_id']), i)]
        

        po_coords = po_cor_tmp2[i].copy()
        po_one = po_one_tmp2[i].copy()
        

        if result['has_inter'] and len(result['inter_coords']) > 0:
            po_coords = np.append(po_coords, result['inter_coords'], axis=0)
            po_one = np.append(po_one, result['inter_one_hot'], axis=0)
        

        if result['has_fg_inter'] and len(result['fg_inter_coords']) > 0:
            po_coords = np.append(po_coords, result['fg_inter_coords'], axis=0)
            po_one = np.append(po_one, result['fg_inter_one_hot'], axis=0)
        
        pocket_coords.append(po_coords)
        pocket_one_hot.append(po_one)
        

        all_fg_coords.append(result['fg_coords'])
        all_fg_one_hot.append(result['fg_one_hot'])
        [all_fg_mask.append(x) for x in np.full(len(result['fg_coords']), i)]
        

        if result['has_cross']:
            adjusted_fg_idx = result['cross_fg_idx'] + fg_idx_offset
            all_cross_atom_idx.append(result['cross_atom_idx'])
            all_cross_fg_idx.append(adjusted_fg_idx)
            n_edges = len(result['cross_atom_idx'])
            [all_cross_mask.append(x) for x in np.full(n_edges, i)]
        

        if result['has_bonds']:
            all_bond_coords.append(result['bond_coords'])
            all_bond_one_hot.append(result['bond_one_hot'])
            all_bond_atom_u.append(result['bond_atom_u'])
            all_bond_atom_v.append(result['bond_atom_v'])
            [all_bond_mask.append(x) for x in np.full(len(result['bond_coords']), i)]
        

        if result['has_fg_inter']:

            for idx_entry, fg_idx_val in zip(result['fg_inter_id'], result['fg_inter_fg_idx']):
                adjusted_entry = [fg_idx_val + fg_idx_offset, 0, idx_entry[2], 0]
                all_fg_inter_id.append(adjusted_entry)
            [all_fg_inter_mask.append(x) for x in np.full(len(result['fg_inter_id']), i)]
        

        fg_idx_offset += len(result['fg_coords'])
        

        n_lig_atoms_i = lig_counts_per_sample[i]
        if 'scaffold_mask' in result:
            all_scaffold_masks.append(result['scaffold_mask'])
            all_growth_points_list.append(result['growth_points'])
        else:
            all_scaffold_masks.append(np.zeros(n_lig_atoms_i, dtype=bool))
            all_growth_points_list.append(np.array([], dtype=int))
        

        if 'middle_mask' in result:
            all_middle_masks.append(result['middle_mask'])
            all_internal_edges.append(result['internal_edges'])
            all_internal_edge_dist.append(result['internal_edge_dist'])
            all_external_edges.append(result['external_edges'])
            all_external_edge_dist.append(result['external_edge_dist'])
            all_final_bond_edges.append(result['final_bond_edges'])
            all_final_bond_probs.append(result['final_bond_probs'])

            all_internal_edge_mask.extend(
                np.full(result['internal_edges'].shape[1], i, dtype=int)
            )
            all_external_edge_mask.extend(
                np.full(result['external_edges'].shape[1], i, dtype=int)
            )
            all_final_bond_mask.extend(
                np.full(result['final_bond_edges'].shape[1], i, dtype=int)
            )
        else:
            all_middle_masks.append(np.zeros(n_lig_atoms_i, dtype=bool))
            all_internal_edges.append(np.zeros((2, 0), dtype=int))
            all_internal_edge_dist.append(np.array([], dtype=np.float32))
            all_external_edges.append(np.zeros((2, 0), dtype=int))
            all_external_edge_dist.append(np.array([], dtype=np.float32))
            all_final_bond_edges.append(np.zeros((2, 0), dtype=int))
            all_final_bond_probs.append(np.array([], dtype=np.float32))
    
    
    # pocket mask
    po_mask = [x for i in range(len(file['names'])) for x in np.full(len(pocket_one_hot[i]), i)]
    po_mask = np.array(po_mask)
    

    inter_id = np.array(inter_id) if len(inter_id) > 0 else np.array([]).reshape(0, 4)
    inter_mask = np.array(inter_mask) if len(inter_mask) > 0 else np.array([], dtype=int)
    

    pocket_coords = np.array([y for x in pocket_coords for y in x]) if pocket_coords else np.array([]).reshape(0, 3)
    pocket_one_hot = np.array([y for x in pocket_one_hot for y in x]) if pocket_one_hot else np.array([]).reshape(0, NEW_DIM)
    

    fg_coords = np.concatenate(all_fg_coords, axis=0) if all_fg_coords else np.array([]).reshape(0, 3)
    fg_one_hot = np.concatenate(all_fg_one_hot, axis=0) if all_fg_one_hot else np.array([]).reshape(0, N_FG_TYPES)
    fg_mask = np.array(all_fg_mask, dtype=int) if all_fg_mask else np.array([], dtype=int)
    

    cross_atom_idx = np.concatenate(all_cross_atom_idx, axis=0) if all_cross_atom_idx else np.array([], dtype=int)
    cross_fg_idx = np.concatenate(all_cross_fg_idx, axis=0) if all_cross_fg_idx else np.array([], dtype=int)
    cross_mask = np.array(all_cross_mask, dtype=int) if all_cross_mask else np.array([], dtype=int)
    

    bond_coords = np.concatenate(all_bond_coords, axis=0) if all_bond_coords else np.array([]).reshape(0, 3)
    bond_one_hot = np.concatenate(all_bond_one_hot, axis=0) if all_bond_one_hot else np.array([]).reshape(0, N_BOND_TYPES)
    bond_mask = np.array(all_bond_mask, dtype=int) if all_bond_mask else np.array([], dtype=int)
    bond_atom_u = np.concatenate(all_bond_atom_u, axis=0) if all_bond_atom_u else np.array([], dtype=int)
    bond_atom_v = np.concatenate(all_bond_atom_v, axis=0) if all_bond_atom_v else np.array([], dtype=int)
    

    fg_inter_id = np.array(all_fg_inter_id) if all_fg_inter_id else np.array([]).reshape(0, 4)
    fg_inter_mask = np.array(all_fg_inter_mask, dtype=int) if all_fg_inter_mask else np.array([], dtype=int)


    internal_edges = np.concatenate(all_internal_edges, axis=1) \
        if all_internal_edges else np.zeros((2, 0), dtype=int)
    internal_edge_dist = np.concatenate(all_internal_edge_dist, axis=0) \
        if all_internal_edge_dist else np.array([], dtype=np.float32)
    internal_edge_mask = np.array(all_internal_edge_mask, dtype=int)

    external_edges = np.concatenate(all_external_edges, axis=1) \
        if all_external_edges else np.zeros((2, 0), dtype=int)
    external_edge_dist = np.concatenate(all_external_edge_dist, axis=0) \
        if all_external_edge_dist else np.array([], dtype=np.float32)
    external_edge_mask = np.array(all_external_edge_mask, dtype=int)

    final_bond_edges = np.concatenate(all_final_bond_edges, axis=1) \
        if all_final_bond_edges else np.zeros((2, 0), dtype=int)
    final_bond_probs = np.concatenate(all_final_bond_probs, axis=0) \
        if all_final_bond_probs else np.array([], dtype=np.float32)
    final_bond_mask = np.array(all_final_bond_mask, dtype=int)
    
    return {
        'inter_id': inter_id,
        'inter_mask': inter_mask,
        'pocket_coords': pocket_coords,
        'pocket_one_hot': pocket_one_hot,
        'pocket_mask': po_mask,
        
        'fg_coords': fg_coords,
        'fg_one_hot': fg_one_hot,
        'fg_mask': fg_mask,
        
        'cross_edge_atom_idx': cross_atom_idx,
        'cross_edge_fg_idx': cross_fg_idx,
        'cross_edge_mask': cross_mask,
        
        'bond_coords': bond_coords,
        'bond_one_hot': bond_one_hot,
        'bond_mask': bond_mask,
        'bond_atom_u': bond_atom_u,
        'bond_atom_v': bond_atom_v,
        
        'fg_inter_id': fg_inter_id,
        'fg_inter_mask': fg_inter_mask,

        'scaffold_masks': all_scaffold_masks,
        'growth_points_list': all_growth_points_list,
        
        'middle_masks': all_middle_masks,
        'internal_edges': internal_edges,
        'internal_edge_dist': internal_edge_dist,
        'internal_edge_mask': internal_edge_mask,
        'external_edges': external_edges,
        'external_edge_dist': external_edge_dist,
        'external_edge_mask': external_edge_mask,
        'final_bond_edges': final_bond_edges,
        'final_bond_probs': final_bond_probs,
        'final_bond_mask': final_bond_mask,
    }


def data_save(data_dir, new_dir, pdb_dir, data_type):

    file_path = Path(data_dir, data_type + '.npz')
    data_file = np.load(file_path)
    
    print(f'=== 数据创建: {data_type} ===')
    result = data_create(data_file, pdb_dir)
    

    out_name = Path(new_dir, data_type + '.npz')
    

    scaffold_mask_flat = np.concatenate(result['scaffold_masks']) if result['scaffold_masks'] else np.array([], dtype=bool)
    middle_mask_flat = np.concatenate(result['middle_masks']) if result['middle_masks'] else np.array([], dtype=bool)
    
    np.savez(out_name,

        names=data_file['names'],
        lig_coords=data_file['lig_coords'],
        lig_one_hot=data_file['lig_one_hot'],
        lig_mask=data_file['lig_mask'],
        pocket_coords=result['pocket_coords'],
        pocket_one_hot=result['pocket_one_hot'],
        pocket_mask=result['pocket_mask'],
        inter_id=result['inter_id'],
        inter_mask=result['inter_mask'],
        

        fg_coords=result['fg_coords'],
        fg_one_hot=result['fg_one_hot'],
        fg_mask=result['fg_mask'],
        

        cross_edge_atom_idx=result['cross_edge_atom_idx'],
        cross_edge_fg_idx=result['cross_edge_fg_idx'],
        cross_edge_mask=result['cross_edge_mask'],
        

        bond_coords=result['bond_coords'],
        bond_one_hot=result['bond_one_hot'],
        bond_mask=result['bond_mask'],
        bond_atom_u=result['bond_atom_u'],
        bond_atom_v=result['bond_atom_v'],
        

        fg_inter_id=result['fg_inter_id'],
        fg_inter_mask=result['fg_inter_mask'],
        

        scaffold_mask=scaffold_mask_flat,
        

        middle_mask=middle_mask_flat,
        internal_edges=result['internal_edges'],
        internal_edge_dist=result['internal_edge_dist'],
        internal_edge_mask=result['internal_edge_mask'],
        external_edges=result['external_edges'],
        external_edge_dist=result['external_edge_dist'],
        external_edge_mask=result['external_edge_mask'],
        final_bond_edges=result['final_bond_edges'],
        final_bond_probs=result['final_bond_probs'],
        final_bond_mask=result['final_bond_mask'],
    )
    
    print(f'  保存完成: {out_name}')
    print(f'  样本数: {len(data_file["names"])}')
    print(f'  官能团总数: {len(result["fg_coords"])}')
    print(f'  跨图边总数: {len(result["cross_edge_atom_idx"])}')
    print(f'  化学键粒子总数: {len(result["bond_coords"])}')
    print(f'  官能团-蛋白交互数: {len(result["fg_inter_id"])}')
    print(f'  骨架原子数: {scaffold_mask_flat.sum()}')
    print(f'  中间原子数: {middle_mask_flat.sum()}')


def main():
    parser = argparse.ArgumentParser(description='跨图建模数据生成')
    parser.add_argument('--data_dir', type=Path, default=None,
                        help='原始npz数据目录（所有split共用，默认）')
    parser.add_argument('--train_data_dir', type=Path, default=None,
                        help='训练集npz数据目录（覆盖--data_dir）')
    parser.add_argument('--val_data_dir', type=Path, default=None,
                        help='验证集npz数据目录（覆盖--data_dir）')
    parser.add_argument('--test_data_dir', type=Path, default=None,
                        help='测试集npz数据目录（覆盖--data_dir）')
    parser.add_argument('--out_dir', type=Path, default=None, help='输出目录')
    parser.add_argument('--pdb_dir', type=Path, default=None,
                        help='PDB/SDF文件目录（所有split共用，默认）')
    parser.add_argument('--train_pdb_dir', type=Path, default=None,
                        help='训练集PDB/SDF目录（覆盖--pdb_dir）')
    parser.add_argument('--val_pdb_dir', type=Path, default=None,
                        help='验证集PDB/SDF目录（覆盖--pdb_dir）')
    parser.add_argument('--test_pdb_dir', type=Path, default=None,
                        help='测试集PDB/SDF目录（覆盖--pdb_dir）')
    parser.add_argument('--skip_existing', action='store_true', default=True)
    args = parser.parse_args()

    args.out_dir.mkdir(exist_ok=args.skip_existing)


    split_dirs = {
        'train': (args.train_data_dir or args.data_dir,
                  args.train_pdb_dir or args.pdb_dir),
        'val':   (args.val_data_dir or args.data_dir,
                  args.val_pdb_dir or args.pdb_dir),
        'test':  (args.test_data_dir or args.data_dir,
                  args.test_pdb_dir or args.pdb_dir),
    }

    for split_name, (d_dir, p_dir) in split_dirs.items():
        if d_dir is None:
            print(f'Warning: 跳过 {split_name}，数据目录未指定')
            continue
        if p_dir is None:
            print(f'Warning: 跳过 {split_name}，PDB目录未指定')
            continue
        npz_path = Path(d_dir, split_name + '.npz')
        if not npz_path.exists():
            print(f'Warning: 未找到 {npz_path}，跳过 {split_name}')
            continue
        data_save(d_dir, args.out_dir, p_dir, split_name)


if __name__ == "__main__":
    main()
