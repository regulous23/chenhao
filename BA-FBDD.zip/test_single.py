import argparse
import warnings
from pathlib import Path
from time import time
import numpy as np
import os

import torch
from rdkit import Chem
from tqdm import tqdm
import oddt

from lightning_modules import LigandPocketDDPM
from analysis.molecule_builder import build_molecule, process_molecule
from dataset import ProcessedLigandPocketDataset
import utils
from constants import dataset_params, FLOAT_TYPE, INT_TYPE
from equivariant_diffusion.conditional_model import ConditionalDDPM
from torch_scatter import scatter_add, scatter_mean
from process_crossdock import process_ligand_and_pocket
from cross_graph_modeling import (
    all_contacts_create, detect_functional_groups,
    build_functional_group_graph, build_cross_edges,
    build_bond_particles, build_oddt_rdkit_atom_mapping,
    fg_protein_interactions_create,
    FG_TYPES, N_FG_TYPES
)
from scaffold_end import process_scaffold_end
from middle_segment import process_middle_segment
from rdkit import Chem


def ligand_generation(test_file, checkpoint, outdir=None, batch_size=4, n_samples=100, relax=True, all_frags=True, save=True):
    #t_pocket_start = time()      
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    x_dims = 3
    model = LigandPocketDDPM.load_from_checkpoint(checkpoint, map_location=device)
    model = model.to(device)

    test_dataset = ProcessedLigandPocketDataset(test_file, center=False)

    if save:
        outdir = Path(outdir)
        outdir.mkdir(exist_ok=True)
        raw_sdf_dir = Path(outdir, 'raw')
        raw_sdf_dir.mkdir(exist_ok=True)
        processed_sdf_dir = Path(outdir, 'processed')
        processed_sdf_dir.mkdir(exist_ok=True)
        sdf_out_file_raw = Path(raw_sdf_dir, test_dataset[0]['names']+'_gen.sdf')
        sdf_out_file_processed = Path(processed_sdf_dir, test_dataset[0]['names']+'_gen.sdf')

    pocket_coords = test_dataset[0]['pocket_coords'].repeat(batch_size,1)
    pocket_one_hot = test_dataset[0]['pocket_one_hot'].repeat(batch_size,1)
    pocket_mask = torch.repeat_interleave(
            torch.arange(batch_size, device=device, dtype=INT_TYPE),len(test_dataset[0]['pocket_mask'])
        )
    pocket_size = torch.tensor([test_dataset[0]['num_pocket_nodes']]*batch_size, device=device, dtype=INT_TYPE)

    pocket ={
        'x': pocket_coords.to(device, FLOAT_TYPE),
        'one_hot': pocket_one_hot.to(device, FLOAT_TYPE),
        'size': pocket_size.to(device, INT_TYPE),
        'mask': pocket_mask.to(device, INT_TYPE)
        }
    
    # Pocket's center of mass
    pocket_com_before = scatter_mean(pocket['x'], pocket['mask'], dim=0)

    num_nodes_lig = None
    if num_nodes_lig is None:
        num_nodes_lig = model.ddpm.size_distribution.sample_conditional(n1=None, n2=pocket['size'])

    # statistical data
    all_molecules = []
    valid_molecules = []
    processed_molecules = []
    n_generated = 0
    n_valid = 0
    iter=0

    while len(valid_molecules) < n_samples:
        iter +=1

        if type(model.ddpm) == ConditionalDDPM: 
            print(type(model.ddpm))
            with torch.no_grad():
                xh_lig, xh_pocket, lig_mask, pocket_mask = model.ddpm.sample_given_pocket(pocket, num_nodes_lig,timesteps=None)

        pocket_com_after = scatter_mean(xh_pocket[:, :x_dims], pocket_mask, dim=0)
        xh_pocket[:, :x_dims] += \
                 (pocket_com_before - pocket_com_after)[pocket_mask]
        xh_lig[:, :x_dims] += \
                (pocket_com_before - pocket_com_after)[lig_mask]
        
        # Build mol objects
        x = xh_lig[:, :x_dims].detach().cpu()
        atom_type = xh_lig[:, x_dims:].argmax(1).detach().cpu()
        lig_mask = lig_mask.cpu()
        
        dataset_info = dataset_params['crossdock_h']

        mols_batch = []
        for mol_pc in zip(utils.batch_to_list(x, lig_mask),
                            utils.batch_to_list(atom_type, lig_mask)):

            mol = build_molecule(*mol_pc, dataset_info, add_coords=True)
            mol = process_molecule(mol,
                                    add_hydrogens=False,
                                    sanitize=True,
                                    relax_iter=0,
                                    largest_frag=False)
            if mol is not None:
                mols_batch.append(mol)

        all_molecules.extend(mols_batch)
        # Filter to find valid molecules
        mols_batch_processed = [
                process_molecule(m, sanitize=True,
                                relax_iter=(200 if relax else 0),
                                largest_frag=not all_frags)
                for m in mols_batch
            ]
        processed_molecules.extend(mols_batch_processed)
        valid_mols_batch = [m for m in mols_batch_processed if m is not None]
        
        n_generated += batch_size
        n_valid += len(valid_mols_batch)
        valid_molecules.extend(valid_mols_batch)

    valid_molecules = valid_molecules[:n_samples]

    # Reorder raw files
    all_molecules = \
        [all_molecules[i] for i, m in enumerate(processed_molecules)
        if m is not None] + \
        [all_molecules[i] for i, m in enumerate(processed_molecules)
        if m is None]

    if save:
        # Write SDF files
        utils.write_sdf_file(sdf_out_file_raw, all_molecules)
        utils.write_sdf_file(sdf_out_file_processed, valid_molecules)

    # Time the sampling process
    #time_per_pocket[str(sdf_file)] = time() - t_pocket_start
    #with open(time_file, 'w') as f:
    #    f.write(f"{str(sdf_file)} {time_per_pocket[str(sdf_file)]}")
    return valid_molecules

def process_data(sdf_file, pdb_file):
    dataset_info = dataset_params['crossdock']
    amino_acid_dict = dataset_info['aa_encoder']
    atom_dict = dataset_info['atom_encoder']
    atom_decoder = dataset_info['atom_decoder']
    dist_cutoff=8.0
    ligand_data, pocket_data = process_ligand_and_pocket(pdb_file,
                                                          sdf_file,
                                                          atom_dict=atom_dict, dist_cutoff=dist_cutoff,amino_acid_dict=amino_acid_dict, ca_only=True)

    lig_mask = np.zeros(len(ligand_data['lig_coords']))
    pocket_mask = np.zeros(len(pocket_data['pocket_coords']))
    file_name = np.array([Path(pdb_file).stem])

    npz_name = 'single1.npz'
    np.savez(npz_name,
        names = file_name,
        lig_coords=ligand_data['lig_coords'],
        lig_one_hot=ligand_data['lig_one_hot'],
        lig_mask = lig_mask,
        pocket_coords=pocket_data['pocket_coords'],
        pocket_one_hot=pocket_data['pocket_one_hot'],
        pocket_mask = pocket_mask
        )
    
    return npz_name
    
def process_data_h(sdf_file, pdb_file, npz_name, use_fgs=True):

    test_npz = np.load(npz_name)
    protein = next(oddt.toolkit.readfile('pdb', pdb_file))
    ligand = next(oddt.toolkit.readfile('sdf', sdf_file))
    protein.protein = True
    ligand.removeh()


    orig_po_oh_dim = test_npz['pocket_one_hot'].shape[1]

    new_po_oh_dim = orig_po_oh_dim + 4


    int_id, inter_coords, inter_one_hot = all_contacts_create(protein, ligand)


    po_one_expanded = np.append(
        test_npz['pocket_one_hot'],
        np.zeros((len(test_npz['pocket_one_hot']), 4)),
        axis=1
    )

    has_inter = len(int_id[0]) > 0 if len(int_id) > 0 else False

    if has_inter and len(inter_one_hot) > 0:

        inter_one_expanded = np.zeros((len(inter_one_hot), new_po_oh_dim))
        inter_one_expanded[:, orig_po_oh_dim:orig_po_oh_dim + 2] = inter_one_hot

        po_int_cor_tmp = np.append(test_npz['pocket_coords'], inter_coords, axis=0)
        po_int_one_tmp = np.append(po_one_expanded, inter_one_expanded, axis=0)
    else:
        po_int_cor_tmp = test_npz['pocket_coords']
        po_int_one_tmp = po_one_expanded

    pocket_mask = np.append(
        test_npz['pocket_mask'],
        np.zeros(len(inter_one_hot)) if has_inter else []
    ).astype(int)
    inter_mask = (np.zeros(len(inter_one_hot)) if has_inter else []).astype(int)


    save_dict = {
        'names': test_npz['names'],
        'lig_coords': test_npz['lig_coords'],
        'lig_one_hot': test_npz['lig_one_hot'],
        'lig_mask': test_npz['lig_mask'],
        'pocket_coords': po_int_cor_tmp,
        'pocket_one_hot': po_int_one_tmp,
        'pocket_mask': pocket_mask,
        'inter_id': np.array(int_id) if has_inter else np.array([]).reshape(0, 4),
        'inter_mask': inter_mask,
    }

    if use_fgs:
        try:

            rdkit_mol = Chem.MolFromMolFile(sdf_file, removeHs=False)
            if rdkit_mol is None or rdkit_mol.GetNumConformers() == 0:
                rdkit_mol = Chem.MolFromMolBlock(
                    ligand.write('sdf'), removeHs=False)

            if rdkit_mol is not None and rdkit_mol.GetNumConformers() > 0:
                oddt_to_rdkit = build_oddt_rdkit_atom_mapping(ligand, rdkit_mol)
                rdkit_to_oddt = {v: k for k, v in oddt_to_rdkit.items()}


                fg_list = detect_functional_groups(rdkit_mol)
                fg_coords, fg_one_hot, fg_rdkit_map = \
                    build_functional_group_graph(rdkit_mol, fg_list)


                n_lig_atoms = len(ligand.atoms)
                cross_atom_idx, cross_fg_idx = build_cross_edges(
                    n_lig_atoms, fg_rdkit_map, rdkit_to_oddt)


                bond_coords, bond_one_hot, bond_u, bond_v = \
                    build_bond_particles(rdkit_mol, rdkit_to_oddt)


                fg_inter_id, fg_inter_coords, fg_inter_one_hot, _ = \
                    fg_protein_interactions_create(
                        protein, ligand, fg_coords, fg_rdkit_map,
                        oddt_to_rdkit)


                if len(fg_inter_coords) > 0:
                    fg_inter_one_expanded = np.zeros(
                        (len(fg_inter_one_hot), new_po_oh_dim))
                    fg_inter_one_expanded[:, orig_po_oh_dim + 2:
                                            orig_po_oh_dim + 4] = fg_inter_one_hot

                    po_int_cor_tmp = np.append(po_int_cor_tmp, fg_inter_coords, axis=0)
                    po_int_one_tmp = np.append(po_int_one_tmp, fg_inter_one_expanded, axis=0)


                    n_fg_inter = len(fg_inter_coords)
                    pocket_mask = np.append(pocket_mask, np.zeros(n_fg_inter)).astype(int)


                save_dict['pocket_coords'] = po_int_cor_tmp
                save_dict['pocket_one_hot'] = po_int_one_tmp
                save_dict['pocket_mask'] = pocket_mask
                save_dict['fg_coords'] = fg_coords
                save_dict['fg_one_hot'] = fg_one_hot
                save_dict['fg_mask'] = np.zeros(len(fg_coords), dtype=int)
                save_dict['cross_edge_atom_idx'] = cross_atom_idx.astype(int)
                save_dict['cross_edge_fg_idx'] = cross_fg_idx.astype(int)
                save_dict['cross_edge_mask'] = np.zeros(len(cross_atom_idx), dtype=int)
                save_dict['bond_coords'] = bond_coords
                save_dict['bond_one_hot'] = bond_one_hot
                save_dict['bond_mask'] = np.zeros(len(bond_coords), dtype=int)
                save_dict['bond_atom_u'] = bond_u.astype(int)
                save_dict['bond_atom_v'] = bond_v.astype(int)
                save_dict['fg_inter_id'] = np.array(fg_inter_id) if len(fg_inter_id) > 0 and len(fg_inter_id[0]) > 0 else np.array([]).reshape(0, 4)
                save_dict['fg_inter_mask'] = np.zeros(len(fg_inter_id), dtype=int) if len(fg_inter_id) > 0 and len(fg_inter_id[0]) > 0 else np.array([], dtype=int)


                lig_coords = test_npz['lig_coords']
                lig_one_hot = test_npz['lig_one_hot']

                scaffold_result = process_scaffold_end(
                    rdkit_mol, lig_coords, lig_one_hot,
                    k_growth_points=3, alpha_att=0.5, alpha_prior=0.5)

                save_dict['scaffold_mask'] = scaffold_result['scaffold_mask']
                save_dict['scaffold_coords'] = scaffold_result['scaffold_coords']
                save_dict['scaffold_one_hot'] = scaffold_result['scaffold_one_hot']
                save_dict['growth_scores'] = scaffold_result['growth_scores']
                save_dict['growth_points'] = scaffold_result['growth_points']
                save_dict['scaffold_atom_indices'] = scaffold_result['scaffold_atom_indices']

                protein_inter_mask = np.zeros(len(lig_coords), dtype=bool)
                if has_inter and len(int_id) > 0 and len(int_id[0]) > 0:
                    for entry in int_id:
                        if len(entry) >= 2 and entry[0] < len(lig_coords):
                            protein_inter_mask[entry[0]] = True

                middle_result = process_middle_segment(
                    lig_coords, lig_one_hot,
                    scaffold_result['scaffold_mask'],
                    protein_inter_mask=protein_inter_mask,
                    build_bond_filter=True, beta=0.8, gamma=0.3, tau=0.3)

                save_dict['middle_mask'] = middle_result['middle_mask']
                save_dict['middle_coords'] = middle_result['middle_coords']
                save_dict['middle_one_hot'] = middle_result['middle_one_hot']
                save_dict['internal_edges'] = middle_result['internal_edges']
                save_dict['internal_edge_dist'] = middle_result['internal_edge_dist']
                save_dict['external_edges'] = middle_result['external_edges']
                save_dict['external_edge_dist'] = middle_result['external_edge_dist']
                save_dict['final_bond_edges'] = middle_result['final_bond_edges']
                save_dict['bond_probs'] = middle_result['bond_probs']
                save_dict['middle_indices'] = middle_result['middle_indices']

        except Exception as e:
            print(f"Warning: functional group processing failed ({e}), "
                  "falling back to basic interaction data only.")


    test_npz_h = 'test.npz'
    np.savez(test_npz_h, **save_dict)
    return test_npz_h


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path,default=None)
    parser.add_argument('--outdir', type=Path)
    parser.add_argument('--pdb', type=str,default=None)
    parser.add_argument('--sdf', type=str,default=None)
    parser.add_argument('--n_samples', type=int, default=100)
    parser.add_argument('--all_frags', action='store_true')
    parser.add_argument('--sanitize', action='store_true')
    parser.add_argument('--relax', action='store_true')
    parser.add_argument('--batch_size', type=int, default=120)
    parser.add_argument('--resamplings', type=int, default=10)
    parser.add_argument('--jump_length', type=int, default=1)
    parser.add_argument('--timesteps', type=int, default=None)
    parser.add_argument('--fix_n_nodes', action='store_true')
    parser.add_argument('--n_nodes_bias', type=int, default=0)
    parser.add_argument('--n_nodes_min', type=int, default=0)
    parser.add_argument('--skip_existing', action='store_true',default=True)
    args = parser.parse_args()

    tmp1 = process_data(sdf_file=args.sdf, pdb_file=args.pdb)
    tmp2 = process_data_h(sdf_file=args.sdf, pdb_file=args.pdb,npz_name=tmp1)   
    ligand_generation(outdir=args.outdir, test_file=tmp2, checkpoint=args.checkpoint, save=True)


if __name__ == "__main__":
    main()