import torch
import torch.nn as nn
import torch.nn.functional as F
from equivariant_diffusion.egnn_new import EGNN, GNN
from equivariant_diffusion.en_diffusion import EnVariationalDiffusion
remove_mean_batch = EnVariationalDiffusion.remove_mean_batch
import numpy as np
import subprocess
from constants import FLOAT_TYPE

class EGNNDynamics(nn.Module):
    def __init__(self, atom_nf, residue_nf,
                 n_dims, joint_nf=16, hidden_nf=64, device='cpu',
                 act_fn=torch.nn.SiLU(), n_layers=4, attention=False,
                 condition_time=True, tanh=False, mode='egnn_dynamics',
                 norm_constant=0, inv_sublayers=2, sin_embedding=False,
                 normalization_factor=100, aggregation_method='sum',
                 update_pocket_coords=True, edge_cutoff_ligand=None,
                 edge_cutoff_pocket=None, edge_cutoff_interaction=None,
                 reflection_equivariant=True, edge_embedding_dim=None):
        super().__init__()
        self.mode = mode
        self.atom_nf = atom_nf
        self.residue_nf = residue_nf
        self.edge_cutoff_l = edge_cutoff_ligand
        self.edge_cutoff_p = edge_cutoff_pocket
        self.edge_cutoff_i = edge_cutoff_interaction
        self.edge_nf = edge_embedding_dim

        self.atom_encoder = nn.Sequential(
            nn.Linear(atom_nf, 2 * atom_nf),
            act_fn,
            nn.Linear(2 * atom_nf, joint_nf)
        )

        self.atom_decoder = nn.Sequential(
            nn.Linear(joint_nf, 2 * atom_nf),
            act_fn,
            nn.Linear(2 * atom_nf, atom_nf)
        )

        self.residue_encoder = nn.Sequential(
            nn.Linear(residue_nf, 2 * residue_nf),
            act_fn,
            nn.Linear(2 * residue_nf, joint_nf)
        )

        self.residue_decoder = nn.Sequential(
            nn.Linear(joint_nf, 2 * residue_nf),
            act_fn,
            nn.Linear(2 * residue_nf, residue_nf)
        )

        # 5 edge types: 0=lig-pocket, 1=lig-lig, 2=pocket-pocket,
        #               3=internal(bond), 4=external(vdw)
        self.n_edge_types = 5
        self.edge_embedding = nn.Embedding(self.n_edge_types, self.edge_nf) \
            if self.edge_nf is not None else None
        self.edge_nf = 0 if self.edge_nf is None else self.edge_nf

        if condition_time:
            dynamics_node_nf = joint_nf + 1
        else:
            print('Warning: dynamics model is _not_ conditioned on time.')
            dynamics_node_nf = joint_nf

        if mode == 'egnn_dynamics':
            self.egnn = EGNN(
                in_node_nf=dynamics_node_nf, in_edge_nf=self.edge_nf,
                hidden_nf=hidden_nf, device=device, act_fn=act_fn,
                n_layers=n_layers, attention=attention, tanh=tanh,
                norm_constant=norm_constant,
                inv_sublayers=inv_sublayers, sin_embedding=sin_embedding,
                normalization_factor=normalization_factor,
                aggregation_method=aggregation_method,
                reflection_equiv=reflection_equivariant
            )
            self.node_nf = dynamics_node_nf
            self.update_pocket_coords = update_pocket_coords

        elif mode == 'gnn_dynamics':
            self.gnn = GNN(
                in_node_nf=dynamics_node_nf + n_dims, in_edge_nf=self.edge_nf,
                hidden_nf=hidden_nf, out_node_nf=n_dims + dynamics_node_nf,
                device=device, act_fn=act_fn, n_layers=n_layers,
                attention=attention, normalization_factor=normalization_factor,
                aggregation_method=aggregation_method)

        self.device = device
        self.n_dims = n_dims
        self.condition_time = condition_time

    def forward(self, xh_atoms, xh_residues, t, mask_atoms, mask_residues,
                scaffold_mask=None, internal_edges=None, external_edges=None,
                final_bond_edges=None, final_bond_probs=None):
        x_atoms = xh_atoms[:, :self.n_dims].clone()
        h_atoms = xh_atoms[:, self.n_dims:].clone()

        x_residues = xh_residues[:, :self.n_dims].clone()
        h_residues = xh_residues[:, self.n_dims:].clone()

        # Adaptive dimension matching for residue features
        # (data dim may differ from model's residue_nf due to dataset configs)
        if h_residues.shape[-1] != self.residue_nf:
            if h_residues.shape[-1] < self.residue_nf:
                h_residues = F.pad(h_residues,
                                   (0, self.residue_nf - h_residues.shape[-1]))
            else:
                h_residues = h_residues[:, :self.residue_nf]

        # embed atom features and residue features in a shared space
        h_atoms = self.atom_encoder(h_atoms)
        h_residues = self.residue_encoder(h_residues)

        # combine the two node types
        x = torch.cat((x_atoms, x_residues), dim=0)
        h = torch.cat((h_atoms, h_residues), dim=0)
        mask = torch.cat([mask_atoms, mask_residues])

        if self.condition_time:
            if np.prod(t.size()) == 1:
                # t is the same for all elements in batch.
                h_time = torch.empty_like(h[:, 0:1]).fill_(t.item())
            else:
                # t is different over the batch dimension.
                h_time = t[mask]
            h = torch.cat([h, h_time], dim=1)

        # get edges of a complete graph
        edges = self.get_edges(mask_atoms, mask_residues, x_atoms, x_residues)
        
        # Guard against empty edge list (too small cutoff)
        if edges.size(1) == 0:
            # No edges: return zero velocities and unchanged features
            vel_atoms = torch.zeros_like(x_atoms)
            vel_residues = torch.zeros_like(x_residues)
            h_out_atoms = self.atom_decoder(self.atom_encoder(h_atoms))
            h_out_residues = self.residue_decoder(self.residue_encoder(h_residues))
            return torch.cat([vel_atoms, h_out_atoms], dim=-1), \
                   torch.cat([vel_residues, h_out_residues], dim=-1)
        
        assert torch.all(mask[edges[0]] == mask[edges[1]])

        # Get edge types: 5 categories
        # 0: ligand-pocket, 1: ligand-ligand, 2: pocket-pocket
        # 3: internal edges (bond constraints), 4: external edges (vdW forces)
        if self.edge_nf > 0:
            n_lig = len(mask_atoms)
            edge_type_ids = torch.zeros(edges.size(1), dtype=torch.long,
                                        device=edges.device)
            edge_type_ids[(edges[0] < n_lig) & (edges[1] < n_lig)] = 1
            edge_type_ids[(edges[0] >= n_lig) & (edges[1] >= n_lig)] = 2

            # 边权：默认1；电负性筛选后的最终键按成键概率加权
            edge_weight = torch.ones(edges.size(1), dtype=FLOAT_TYPE,
                                     device=edges.device)

            # 中间段约束：把对应的配体-配体图边改写为专用类型。
            # 配体节点在全局图中排在最前，因此配体局部索引即全局索引。
            n_nodes = len(mask)
            gidx, _ = self._locate_pairs(edges, external_edges, n_nodes)
            if gidx is not None:
                edge_type_ids[gidx] = 4
            gidx, _ = self._locate_pairs(edges, internal_edges, n_nodes)
            if gidx is not None:
                edge_type_ids[gidx] = 3
            gidx, pidx = self._locate_pairs(edges, final_bond_edges, n_nodes)
            if gidx is not None:
                # 最终筛选键是内部候选边的子集，最后标记以覆盖类型3
                edge_type_ids[gidx] = 3
                if final_bond_probs is not None:
                    edge_weight[gidx] = \
                        final_bond_probs[pidx].to(FLOAT_TYPE).clamp(0.0, 1.0)

            # Learnable embedding，键概率作为边权缩放
            edge_types = self.edge_embedding(edge_type_ids) * \
                         edge_weight.unsqueeze(1)
        else:
            edge_types = None

        if self.mode == 'egnn_dynamics':
            # Build update_coords_mask: scaffold atoms don't update coords
            if self.update_pocket_coords:
                update_coords_mask = None
            else:
                base_mask = torch.cat((torch.ones_like(mask_atoms, dtype=FLOAT_TYPE),
                                       torch.zeros_like(mask_residues, dtype=FLOAT_TYPE)))
                # If scaffold_mask provided, also freeze scaffold atoms
                if scaffold_mask is not None:
                    # scaffold_mask is bool tensor over ligand atoms only
                    scaffold_float = (~scaffold_mask).to(FLOAT_TYPE)  # 0 for scaffold, 1 for others
                    base_mask[:len(mask_atoms)] = base_mask[:len(mask_atoms)] * scaffold_float
                    # Guard: ensure at least one atom can move (avoid all-zero mask)
                    if base_mask[:len(mask_atoms)].sum() == 0:
                        base_mask[0] = 1.0  # keep first atom movable
                update_coords_mask = base_mask.unsqueeze(1)

            h_final, x_final = self.egnn(h, x, edges,
                                         update_coords_mask=update_coords_mask,
                                         batch_mask=mask, edge_attr=edge_types)

            vel = (x_final - x)

        elif self.mode == 'gnn_dynamics':
            xh = torch.cat([x, h], dim=1)
            output = self.gnn(xh, edges, node_mask=None, edge_attr=edge_types)
            vel = output[:, :3]
            h_final = output[:, 3:]

        else:
            raise Exception("Wrong mode %s" % self.mode)

        if self.condition_time:
            # Slice off last dimension which represented time.
            h_final = h_final[:, :-1]

        # decode atom and residue features
        h_final_atoms = self.atom_decoder(h_final[:len(mask_atoms)])
        h_final_residues = self.residue_decoder(h_final[len(mask_atoms):])

        # Numerical stability: handle NaN/Inf in velocities
        if torch.any(torch.isnan(vel)) or torch.any(torch.isinf(vel)):
            vel[torch.isnan(vel)] = 0.0
            vel[torch.isinf(vel)] = 0.0

        if self.update_pocket_coords:
            # in case of unconditional joint distribution, include this as in
            # the original code
            vel = remove_mean_batch(vel, mask)

        return torch.cat([vel[:len(mask_atoms)], h_final_atoms], dim=-1), \
               torch.cat([vel[len(mask_atoms):], h_final_residues], dim=-1)

    @staticmethod
    def _locate_pairs(edges, pair_edges, n_nodes):
        """在全局图边列表中定位给定的配体-配体边（双向匹配）。

        参数:
            edges: (2, E) 全局图边（节点索引，配体在前口袋在后）
            pair_edges: (2, M) 配体原子索引对；配体局部索引即全局索引
            n_nodes: 全局节点总数，用于把 (u, v) 编码为唯一键

        返回:
            (graph_idx, pair_idx)：匹配到的图边下标及其对应的 pair 下标；
            输入为空时返回 (None, None)。找不到的边会被忽略（例如超出
            距离截断的边不在图里）。
        """
        if pair_edges is None or pair_edges.numel() == 0 or \
                edges.numel() == 0:
            return None, None

        src = pair_edges[0].long()
        dst = pair_edges[1].long()
        n_pairs = src.numel()

        # 无向边在邻接矩阵中双向出现，两个方向都要标记
        q_keys = torch.cat([src * n_nodes + dst, dst * n_nodes + src])
        q_pid = torch.cat([
            torch.arange(n_pairs, device=pair_edges.device),
            torch.arange(n_pairs, device=pair_edges.device),
        ])

        g_keys = edges[0] * n_nodes + edges[1]
        sorted_keys, perm = torch.sort(g_keys)
        pos = torch.searchsorted(sorted_keys, q_keys).clamp(
            max=sorted_keys.numel() - 1)
        found = sorted_keys[pos] == q_keys
        if not bool(found.any()):
            return None, None
        return perm[pos[found]], q_pid[found]

    def get_edges(self, batch_mask_ligand, batch_mask_pocket, x_ligand, x_pocket):
        adj_ligand = batch_mask_ligand[:, None] == batch_mask_ligand[None, :]
        adj_pocket = batch_mask_pocket[:, None] == batch_mask_pocket[None, :]
        adj_cross = batch_mask_ligand[:, None] == batch_mask_pocket[None, :]

        if self.edge_cutoff_l is not None:
            adj_ligand = adj_ligand & (torch.cdist(x_ligand, x_ligand) <= self.edge_cutoff_l)

        if self.edge_cutoff_p is not None:
            adj_pocket = adj_pocket & (torch.cdist(x_pocket, x_pocket) <= self.edge_cutoff_p)

        if self.edge_cutoff_i is not None:
            adj_cross = adj_cross & (torch.cdist(x_ligand, x_pocket) <= self.edge_cutoff_i)

        adj = torch.cat((torch.cat((adj_ligand, adj_cross), dim=1),
                         torch.cat((adj_cross.T, adj_pocket), dim=1)), dim=0)

        edges = torch.stack(torch.where(adj), dim=0)

        return edges
