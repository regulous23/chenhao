
import numpy as np
import torch


BOND_DIST_MIN = 1.0   
BOND_DIST_MAX = 2.0   


VDW_DIST_MIN = 2.5
VDW_DIST_MAX = 5.0


ELECTRONEGATIVITY = {
    1: 2.20,   # H
    6: 2.55,   # C
    7: 3.04,   # N
    8: 3.44,   # O
    9: 3.98,   # F
    15: 2.19,  # P
    16: 2.58,  # S
    17: 3.16,  # Cl
    35: 2.96,  # Br
    53: 2.66,  # I
}

ELECTRON_AFFINITY_TENDENCY = {
    1: 0.0,    # H
    6: 0.3,    # C
    7: 0.7,    # N
    8: 0.9,    # O
    9: 1.0,    # F
    15: 0.4,   # P
    16: 0.6,   # S
    17: 0.95,  # Cl
    35: 0.85,  # Br
    53: 0.75,  # I
}


def identify_middle_atoms(n_atoms, scaffold_mask, protein_inter_mask=None):

    if protein_inter_mask is None:
        protein_inter_mask = np.zeros(n_atoms, dtype=bool)

    middle_mask = ~(scaffold_mask | protein_inter_mask)
    return middle_mask


def build_internal_edges(coords, d0=BOND_DIST_MIN, d1=BOND_DIST_MAX):

    n = len(coords)
    if n == 0:
        return np.zeros((2, 0), dtype=int), np.array([])

    edges = []
    dists = []

    for i in range(n):
        for j in range(i + 1, n):
            dist = np.linalg.norm(coords[i] - coords[j])
            if d0 <= dist <= d1:
                edges.append([i, j])
                edges.append([j, i])
                dists.append(dist)
                dists.append(dist)

    if len(edges) == 0:
        return np.zeros((2, 0), dtype=int), np.array([])

    edge_index = np.array(edges, dtype=int).T
    edge_dist = np.array(dists, dtype=np.float32)

    return edge_index, edge_dist


def build_external_edges(middle_coords, known_coords,
                         d_min=VDW_DIST_MIN, d_max=VDW_DIST_MAX):

    n_middle = len(middle_coords)
    n_known = len(known_coords)

    if n_middle == 0 or n_known == 0:
        return np.zeros((2, 0), dtype=int), np.array([])

    edges = []
    dists = []

    for i in range(n_middle):
        for j in range(n_known):
            dist = np.linalg.norm(middle_coords[i] - known_coords[j])
            if d_min <= dist <= d_max:
                edges.append([i, j])
                dists.append(dist)

    if len(edges) == 0:
        return np.zeros((2, 0), dtype=int), np.array([])

    edge_index = np.array(edges, dtype=int).T
    edge_dist = np.array(dists, dtype=np.float32)

    return edge_index, edge_dist


def electrogativity_bond_filter(coords, atom_types_one_hot,
                                candidate_edges, beta=0.8, gamma=0.3,
                                tau=0.3):

    if candidate_edges.shape[1] == 0:
        return np.zeros((2, 0), dtype=int), np.array([])


    atom_types = atom_types_one_hot.argmax(axis=1)


    en_map = ELECTRONEGATIVITY

    probs = []
    valid_edges = []

    for k in range(candidate_edges.shape[1]):
        i, j = candidate_edges[0, k], candidate_edges[1, k]

        type_i = int(atom_types[i])
        type_j = int(atom_types[j])

        xi = _get_electronegativity(type_i)
        xj = _get_electronegativity(type_j)

        polarity_term = np.exp(-beta * abs(xi - xj))
        penalty_term = max(0.0, 1.0 - gamma * max(xi, xj) / 4.0)
        prob = polarity_term * penalty_term

        probs.append(prob)

        if prob >= tau:
            valid_edges.append([i, j])

    bond_probs = np.array(probs, dtype=np.float32)

    if len(valid_edges) == 0:
        return np.zeros((2, 0), dtype=int), bond_probs

    final_edges = np.array(valid_edges, dtype=int).T
    return final_edges, bond_probs


def _get_electronegativity(atom_type_idx):

    idx_to_z = {0: 6, 1: 7, 2: 8, 3: 16, 4: 5, 5: 35, 6: 17, 7: 15, 8: 53, 9: 9}
    z = idx_to_z.get(atom_type_idx, 6)  
    return ELECTRONEGATIVITY.get(z, 2.55)


def process_middle_segment(ligand_coords, ligand_one_hot,
                           scaffold_mask, protein_inter_mask=None,
                           build_bond_filter=True, beta=0.8,
                           gamma=0.3, tau=0.3):

    n_atoms = ligand_coords.shape[0]


    middle_mask = identify_middle_atoms(n_atoms, scaffold_mask, protein_inter_mask)
    middle_indices = np.where(middle_mask)[0]

    if len(middle_indices) == 0:

        return {
            'middle_mask': middle_mask,
            'middle_coords': np.zeros((0, 3), dtype=np.float32),
            'middle_one_hot': np.zeros((0, ligand_one_hot.shape[1]), dtype=np.float32),
            'internal_edges': np.zeros((2, 0), dtype=int),
            'internal_edge_dist': np.array([]),
            'external_edges': np.zeros((2, 0), dtype=int),
            'external_edge_dist': np.array([]),
            'final_bond_edges': np.zeros((2, 0), dtype=int),
            'bond_probs': np.array([]),
            'final_bond_probs': np.array([]),
            'middle_indices': np.array([], dtype=int),
        }


    middle_coords = ligand_coords[middle_mask]
    middle_one_hot = ligand_one_hot[middle_mask]


    internal_edges, internal_edge_dist = build_internal_edges(
        ligand_coords, d0=BOND_DIST_MIN, d1=BOND_DIST_MAX)


    known_mask = scaffold_mask if protein_inter_mask is None else (scaffold_mask | protein_inter_mask)
    known_coords = ligand_coords[known_mask]


    ext_edges, ext_edge_dist = build_external_edges(
        middle_coords, known_coords,
        d_min=VDW_DIST_MIN, d_max=VDW_DIST_MAX)


    known_indices = np.where(known_mask)[0]
    if ext_edges.shape[1] > 0:
        ext_edges[1] = known_indices[ext_edges[1]]


    final_bond_edges = internal_edges.copy()
    bond_probs = np.ones(internal_edges.shape[1], dtype=np.float32) \
        if internal_edges.shape[1] > 0 else np.array([], dtype=np.float32)
    final_bond_probs = bond_probs.copy()

    if build_bond_filter and internal_edges.shape[1] > 0:
        final_bond_edges, bond_probs = electrogativity_bond_filter(
            ligand_coords, ligand_one_hot, internal_edges,
            beta=beta, gamma=gamma, tau=tau)
        final_bond_probs = bond_probs[bond_probs >= tau].astype(np.float32)

        if len(final_bond_probs) != final_bond_edges.shape[1]:
            raise ValueError(
                'final_bond_probs and final_bond_edges have inconsistent '
                f'lengths: {len(final_bond_probs)} vs '
                f'{final_bond_edges.shape[1]}'
            )

    return {
        'middle_mask': middle_mask,
        'middle_coords': middle_coords,
        'middle_one_hot': middle_one_hot,
        'internal_edges': internal_edges,
        'internal_edge_dist': internal_edge_dist,
        'external_edges': ext_edges,
        'external_edge_dist': ext_edge_dist,
        'final_bond_edges': final_bond_edges,
        'bond_probs': bond_probs,
        'final_bond_probs': final_bond_probs,
        'middle_indices': middle_indices,
    }


def equivariant_message_passing(node_coords, node_features, edge_index,
                                edge_attr=None, n_layers=3):

    n = len(node_coords)
    if n == 0 or edge_index.shape[1] == 0:
        return node_coords.copy(), node_features.copy()

    coords = node_coords.copy()
    features = node_features.copy()

    for _ in range(n_layers):

        new_features = features.copy()
        for e in range(edge_index.shape[1]):
            i, j = edge_index[0, e], edge_index[1, e]

            msg = features[j]
            if edge_attr is not None and e < len(edge_attr):

                dist_weight = 1.0 / (1.0 + edge_attr[e])
                msg = msg * dist_weight
            new_features[i] += msg

        features = new_features / (1 + n_layers) 
    return coords, features
