
import argparse
import os
import sys
from pathlib import Path

import numpy as np
from rdkit import Chem, RDLogger
from rdkit.Chem import QED, Crippen, Lipinski, Descriptors, DataStructs, AllChem

RDLogger.DisableLog('rdApp.*')


try:
    from rdkit.Contrib.SA_Score import sascorer
except ImportError:
    from rdkit import RDConfig
    sys.path.append(os.path.join(RDConfig.RDContribDir, 'SA_Score'))
    import sascorer


def mol_properties(mol):
    """计算单个分子的各项指标"""
    mw = Descriptors.MolWt(mol)
    logp = Crippen.MolLogP(mol)
    hbd = Lipinski.NumHDonors(mol)
    hba = Lipinski.NumHAcceptors(mol)
    rotb = Lipinski.NumRotatableBonds(mol)
    tpsa = Descriptors.TPSA(mol)


    lipinski_rules = int(mw < 500) + int(logp < 5) + int(hbd <= 5) + int(hba <= 10)

    return {
        'smiles': Chem.MolToSmiles(mol),
        'QED': QED.qed(mol),
        'SA': sascorer.calculateScore(mol),
        'LogP': logp,
        'MW': mw,
        'HBD': hbd,
        'HBA': hba,
        'TPSA': tpsa,
        'RotB': rotb,
        'Lipinski': lipinski_rules,
    }


def pairwise_diversity(mols):

    if len(mols) < 2:
        return 0.0, 0.0
    fps = [AllChem.GetMorganFingerprintAsBitVect(m, 2, 2048) for m in mols]
    sims = []
    for i in range(len(fps)):
        for j in range(i + 1, len(fps)):
            sims.append(DataStructs.TanimotoSimilarity(fps[i], fps[j]))
    sims = np.array(sims)
    diversity = 1.0 - sims.mean()
    similarity = sims.mean()
    return diversity, similarity


def evaluate_sdf(sdf_path):

    supplier = Chem.SDMolSupplier(str(sdf_path))
    mols = [m for m in supplier if m is not None]
    n_total = len(supplier) if hasattr(supplier, '__len__') else len(mols)

    rows = []
    for i, mol in enumerate(mols):
        try:
            props = mol_properties(mol)
            props['mol_idx'] = i
            rows.append(props)
        except Exception:
            continue

    diversity, similarity = pairwise_diversity(mols)
    validity = len(rows) / max(n_total, 1)

    return rows, {
        'n_generated': n_total,
        'n_valid': len(rows),
        'Validity': validity,
        'Diversity': diversity,
        'Similarity': similarity,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gen_dir', type=Path, required=True,
                        help='生成的SDF文件目录（如 sample/processed）')
    parser.add_argument('--out_csv', type=Path, required=True,
                        help='指标输出CSV路径')
    args = parser.parse_args()
    args.out_csv.parent.mkdir(parents=True, exist_ok=True)

    sdf_files = sorted(args.gen_dir.glob('*.sdf'))
    assert len(sdf_files) > 0, f'未找到SDF文件: {args.gen_dir}'

    all_rows = []       
    summary_rows = []   

    for sdf_file in sdf_files:
        pocket_name = sdf_file.stem
        rows, stats = evaluate_sdf(sdf_file)

        for r in rows:
            r['pocket'] = pocket_name
        all_rows.extend(rows)

        if len(rows) > 0:
            qed = [r['QED'] for r in rows]
            sa = [r['SA'] for r in rows]
            logp = [r['LogP'] for r in rows]
            lip = [r['Lipinski'] for r in rows]
            summary_rows.append({
                'pocket': pocket_name,
                'n_generated': stats['n_generated'],
                'n_valid': stats['n_valid'],
                'Validity': stats['Validity'],
                'QED_mean': np.mean(qed), 'QED_std': np.std(qed),
                'SA_mean': np.mean(sa), 'SA_std': np.std(sa),
                'LogP_mean': np.mean(logp), 'LogP_std': np.std(logp),
                'Lipinski_mean': np.mean(lip), 'Lipinski_std': np.std(lip),
                'Diversity': stats['Diversity'],
                'Similarity': stats['Similarity'],
            })
        print(f"{pocket_name}: {stats['n_valid']} valid, "
              f"QED={np.mean([r['QED'] for r in rows]) if rows else 0:.3f}, "
              f"SA={np.mean([r['SA'] for r in rows]) if rows else 0:.3f}, "
              f"Div={stats['Diversity']:.3f}")


    import csv
    out_detail = args.out_csv.with_name(args.out_csv.stem + '_detail.csv')
    if all_rows:
        with open(out_detail, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
            writer.writeheader()
            writer.writerows(all_rows)


    if summary_rows:
        with open(args.out_csv, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
            writer.writeheader()
            writer.writerows(summary_rows)


    keys = ['Validity', 'QED_mean', 'SA_mean', 'LogP_mean',
            'Lipinski_mean', 'Diversity', 'Similarity']
    print('\n===== 全局汇总 (mean ± std) =====')
    global_line = {}
    for k in keys:
        vals = [r[k] for r in summary_rows]
        if len(vals) > 0:
            global_line[k] = f"{np.mean(vals):.4f} ± {np.std(vals):.4f}"
        else:
            global_line[k] = '无有效分子'
        print(f"  {k:15s}: {global_line[k]}")


    out_summary = args.out_csv.with_name(args.out_csv.stem + '_global.txt')
    with open(out_summary, 'w') as f:
        for k, v in global_line.items():
            f.write(f"{k}: {v}\n")

    print(f'\n已保存:')
    print(f'  逐分子明细: {out_detail}')
    print(f'  逐口袋汇总: {args.out_csv}')
    print(f'  全局汇总:   {out_summary}')


if __name__ == '__main__':
    main()
