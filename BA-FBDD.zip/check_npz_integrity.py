
import argparse
from pathlib import Path

import numpy as np

from dataset import ProcessedLigandPocketDataset


MIDDLE_FIELDS = (
    'internal_edges', 'internal_edge_dist', 'internal_edge_mask',
    'external_edges', 'external_edge_dist', 'external_edge_mask',
    'final_bond_edges', 'final_bond_probs', 'final_bond_mask',
)


def check_split(npz_path: Path) -> bool:
    print(f'\n===== 检查 {npz_path} =====')
    ok = True

    with np.load(npz_path, allow_pickle=True) as f:
        keys = set(f.keys())


    missing = [k for k in MIDDLE_FIELDS if k not in keys]
    if missing:
        print(f'  [错误] 缺少中间段字段: {missing}')
        print('         该 NPZ 是旧版预处理生成的，请用新版 '
              'cross_graph_modeling.py 重新预处理。')
        return False


    try:
        ds = ProcessedLigandPocketDataset(npz_path, center=False)
    except Exception as e:
        print(f'  [错误] 数据集加载/拆分失败: {e}')
        return False
    n_samples = len(ds)
    print(f'  样本数: {n_samples}')


    n_with_scaffold = 0
    n_internal, n_external, n_final = 0, 0, 0
    probs_min, probs_max = np.inf, -np.inf

    for i in range(n_samples):
        d = ds[i]
        n_lig = int(d['num_lig_atoms'])
        name = d['names']


        for k in ('scaffold_mask', 'middle_mask'):
            if len(d[k]) != n_lig:
                print(f'  [错误] 样本{i}({name}): {k} 长度 '
                      f'{len(d[k])} != 配体原子数 {n_lig}')
                ok = False
        if bool(d['scaffold_mask'].any()):
            n_with_scaffold += 1


        for edges_key, dist_key in (
                ('internal_edges', 'internal_edge_dist'),
                ('external_edges', 'external_edge_dist'),
                ('final_bond_edges', None)):
            e = d[edges_key]
            if e.dim() != 2 or e.shape[0] != 2:
                print(f'  [错误] 样本{i}({name}): {edges_key} 形状 '
                      f'{tuple(e.shape)}，应为 (2, N)')
                ok = False
                continue
            if e.numel() == 0:
                continue
            if int(e.min()) < 0 or int(e.max()) >= n_lig:
                print(f'  [错误] 样本{i}({name}): {edges_key} 端点越界 '
                      f'[{int(e.min())}, {int(e.max())}]，配体原子数 {n_lig}')
                ok = False
            if dist_key is not None and len(d[dist_key]) != e.shape[1]:
                print(f'  [错误] 样本{i}({name}): {dist_key} 长度 '
                      f'{len(d[dist_key])} != 边数 {e.shape[1]}')
                ok = False

        n_internal += d['internal_edges'].shape[1]
        n_external += d['external_edges'].shape[1]
        n_final += d['final_bond_edges'].shape[1]


        p = d['final_bond_probs']
        if len(p) != d['final_bond_edges'].shape[1]:
            print(f'  [错误] 样本{i}({name}): final_bond_probs 长度 '
                  f'{len(p)} != final_bond_edges 边数 '
                  f'{d["final_bond_edges"].shape[1]}')
            ok = False
        if len(p):
            probs_min = min(probs_min, float(p.min()))
            probs_max = max(probs_max, float(p.max()))


    print(f'  含骨架原子的样本: {n_with_scaffold}/{n_samples} '
          f'({100.0 * n_with_scaffold / max(n_samples, 1):.1f}%)')
    print(f'  内部边总数: {n_internal} | 外部边总数: {n_external} | '
          f'最终键总数: {n_final}')
    if n_final:
        print(f'  final_bond_probs 范围: [{probs_min:.4f}, {probs_max:.4f}]')
        if probs_min < 0.0 or probs_max > 1.0:
            print('  [错误] final_bond_probs 超出 [0, 1] 范围')
            ok = False
    if n_with_scaffold == 0:
        print('  [警告] 没有任何样本含骨架原子，has_scaffold 将仍为0')
        ok = False

    print(f'  结果: {"通过" if ok else "存在问题"}')
    return ok


def main():
    parser = argparse.ArgumentParser(description='预处理数据完整性检查')
    parser.add_argument('--datadir', type=Path, required=True,
                        help='预处理 NPZ 所在目录（如 data/crossdocked_ca_Int）')
    parser.add_argument('--splits', type=str, nargs='+',
                        default=['train', 'val', 'test'],
                        help='要检查的 split（默认 train val test）')
    args = parser.parse_args()

    all_ok = True
    for split in args.splits:
        npz_path = Path(args.datadir, f'{split}.npz')
        if not npz_path.exists():
            print(f'\n===== 跳过 {npz_path}（文件不存在）=====')
            continue
        all_ok &= check_split(npz_path)

    print('\n===== 总体结果:',
          '全部通过，可以开始训练 =====' if all_ok else
          '存在问题，请先修复 =====')


if __name__ == '__main__':
    main()
